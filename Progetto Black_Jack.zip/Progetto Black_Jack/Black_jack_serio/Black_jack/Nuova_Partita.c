#include "Testa.h"


void Nuova_Partita(Tsettings opzione,Tgiocatore *giocatore,Tcarte *deck,Tbanco *banco,Trecord *record,int *salva_esci,int * indice){
    int max_giocatore=0;
    (*indice)=0;
    do{
        Azzerare_Tutto(giocatore,banco,indice,opzione.num_giocatori,salva_esci);
        Inizializza_Mazzo(deck);
        Mischiare_Mazzo(deck);
        system("cls");
        Stampare_Campo(opzione,giocatore);
        Eseguire_Puntata(opzione.num_giocatori,giocatore,salva_esci);
        system("cls");
        if((*salva_esci)==0){
            Stampare_Campo(opzione,giocatore);
            Distribuire_Carte(opzione,giocatore,banco,indice,deck);
            Sommare_Valore(giocatore,opzione.num_giocatori,banco);
            Stampare_Giocatori(opzione.num_giocatori,giocatore,deck,0);
            if(opzione.stile==1){

                Stampare_Banco_Americano(banco,deck);
            }else{
                Stampare_Banco(banco,deck);
            }
            Eseguire_Mosse_Giocatore(opzione.num_giocatori,giocatore,deck,indice,banco,salva_esci);
            Stampare_Giocatori(opzione.num_giocatori,giocatore,deck,0);
        }
        if((*salva_esci)==0){
            Eseguire_Mosse_Banco(banco,deck,indice,opzione.num_giocatori);
            Distribuire_Vincita(giocatore,banco,opzione.num_giocatori,deck);
            Eliminare_Giocatore(giocatore,&opzione.num_giocatori);
            Trovare_Credito_Maggiore(giocatore,opzione.num_giocatori,&max_giocatore);
            //giocatore[max_giocatore].credito=7000;
        }
    }while(giocatore[max_giocatore].credito<15000&&opzione.num_giocatori>0&&(*salva_esci)==0);

    if((*salva_esci)==0){
        Leggi_Record(record);
        Scrivi_Record(giocatore,opzione.difficolta,record,max_giocatore);
    }

    if((*salva_esci)==2){

        int stile=opzione.stile;
        Salvare_Partita(giocatore,&opzione,&stile);
    }

    gotoxy(20,4);



}






void Inizializza_Mazzo(Tcarte *deck){
    int i=0;
    int k=0;
    strcpy(deck->grafica[0],"A");
    strcpy(deck->grafica[1],"2");
    strcpy((*deck).grafica[2],"3");
    strcpy((*deck).grafica[3],"4");
    strcpy((*deck).grafica[4],"5");
    strcpy((*deck).grafica[5],"6");
    strcpy((*deck).grafica[6],"7");
    strcpy((*deck).grafica[7],"8");
    strcpy((*deck).grafica[8],"9");
    strcpy((*deck).grafica[9],"10");
    strcpy((*deck).grafica[10],"J");
    strcpy((*deck).grafica[11],"Q");
    strcpy((*deck).grafica[12],"K");

    while(i<MAXCARTE){

// inizializza "simboli" carta
        (*deck).mazzo[i][0]=k;
//=======Inizializza il seme
        if(i<26){
            (*deck).mazzo[i][1]=CUORI;
        }else{
            if(i<52){
                (*deck).mazzo[i][1]=PICCHE;
            }else{
                if(i<78){
                    (*deck).mazzo[i][1]=QUADRI;
                }else{
                    (*deck).mazzo[i][1]=FIORI;
                }
            }// fine else
        }
//=======Assegna valore a carta
       if(k>9){
            (*deck).mazzo[i][2]=10;
        }else{
            (*deck).mazzo[i][2]=k+1;
        }//fine else
//incremento del k e azzeramento
        k++;
        if(k>12){
            k=0;
        }
//incremento della i
        i++;

    }// fine while




}

void Mischiare_Mazzo(Tcarte *deck){

    int n;
    int r;
    int giro;
    randomize;
    giro=random(1000);
    while(giro>0){
    n= MAXCARTE-1;
        while(n!=0){
//prepariamo la random con la randomize
            randomize;
            r=random(n);
    //inseriamo in dep i valori contenuti in posizione r
            (*deck).dep[0][0]=(*deck).mazzo[r][0];
            (*deck).dep[0][1]=(*deck).mazzo[r][1];
            (*deck).dep[0][2]=(*deck).mazzo[r][2];
    //inseriamo in r i valori contenuti in posizione n
            (*deck).mazzo[r][0]=(*deck).mazzo[n][0];
            (*deck).mazzo[r][1]=(*deck).mazzo[n][1];
            (*deck).mazzo[r][2]=(*deck).mazzo[n][2];
    //inseriamo in n i valori contenuti in dep
            (*deck).mazzo[n][0]=(*deck).dep[0][0];
            (*deck).mazzo[n][1]=(*deck).dep[0][1];
            (*deck).mazzo[n][2]=(*deck).dep[0][2];

            n--;

        }
        giro--;
    }
     /*  i=0;
        while(i<MAXCARTE){

        printf("%s %c %d\t",(*deck).grafica[(*deck).mazzo[i][0]],(*deck).mazzo[i][1],(*deck).mazzo[i][2]);
        i++;
    }
    */
}


void Eseguire_Puntata(int num_giocatori,Tgiocatore *giocatore,int *salva_esci){

    int i=0;
    int x=26;
    int y=11;
    char scelta;
    int flag=0;
    int salva=1;

    Abilitare_Salva();
    Resettare_Puntata(num_giocatori,giocatore);
    while(i<num_giocatori&&(*salva_esci)==0){
    Stampare_Menu_Puntata(i,giocatore);
        do{
        gotoxy(27,9);
        colore(giocatore[i].sceltacolore+CBASE);
        printf("Giocatore%d",i+1);
        colore(CBASE);
        gotoxy(27,10);
        printf("Seleziona la sua puntata:");
        printf("%d   ",giocatore[i].puntata);
        gotoxy(x,y);//Funzione utilizzata per stampare in posizione X-Y della console
        printf("%c",FRECCIA);//stampa la define FRECCIA
        gotoxy(25,9);
        scelta=Acq_Char();//acquisisce il char da tastiera (input utente)
        Spostamento_Puntata(scelta,&x,y);// gestisce lo spostamento del "cursore"


            if(scelta==INVIO&&x==26){

                if(giocatore[i].credito-10>=0){

                    giocatore[i].puntata+=10;
                    giocatore[i].credito-=10;
                    Stampare_Menu_Puntata(i,giocatore);
                    Oscurare_Salva();
                    salva=0;
                }

            }
            if(scelta==INVIO&&x==30){

                if(giocatore[i].credito-50>=0){

                    giocatore[i].puntata+=50;
                    giocatore[i].credito-=50;
                    Stampare_Menu_Puntata(i,giocatore);
                    Oscurare_Salva();
                    salva=0;
                }

            }
            if(scelta==INVIO&&x==34){

                if(giocatore[i].credito-100>=0){

                    giocatore[i].puntata+=100;
                    giocatore[i].credito-=100;
                    Stampare_Menu_Puntata(i,giocatore);
                    Oscurare_Salva();
                    salva=0;
                }


            }

            if(scelta==INVIO&&x==38){

                if(giocatore[i].credito-200>=0){

                    giocatore[i].puntata+=200;
                    giocatore[i].credito-=200;
                    Stampare_Menu_Puntata(i,giocatore);
                    Oscurare_Salva();
                    salva=0;
                }

            }
            if(scelta==INVIO&&x==42){

                if(giocatore[i].credito-500>=0){

                    giocatore[i].puntata+=500;
                    giocatore[i].credito-=500;
                    Stampare_Menu_Puntata(i,giocatore);
                    Oscurare_Salva();
                    salva=0;
                }

            }

            if(scelta==INVIO&&x==49&&giocatore[i].puntata!=0){

                flag++;
            }
//=========TASTO ESC
            if(scelta==ESC){
                (*salva_esci)=1;
            }
//=========TASTO S
            if(scelta==S&& salva==1){
                (*salva_esci)=2;
            }

        }while(flag==0&&(*salva_esci)==0);//while(scelta!=INVIO&&x!=37&&(*giocatore).puntata>0);

        i++;
        flag=0;

    }


}


void Distribuire_Carte(Tsettings opzione,Tgiocatore *giocatore,Tbanco *banco,int *indice,Tcarte *deck){


    int giri=0;
    int i=0;
    while(giri<2){

        i=0;
        while(i<opzione.num_giocatori){

            giocatore[i].carte[giri][0]=(*deck).mazzo[(*indice)][0];
            giocatore[i].carte[giri][1]=(*deck).mazzo[(*indice)][1];
            giocatore[i].carte[giri][2]=(*deck).mazzo[(*indice)][2];
            giocatore[i].num_carte++;
            (*indice)++;
            i++;
        }
        if(giri>0){

            if(opzione.stile==1){

                (*banco).carte[giri][0]= (*deck).mazzo[(*indice)][0];
                (*banco).carte[giri][1]= (*deck).mazzo[(*indice)][1];
                (*banco).carte[giri][2]= (*deck).mazzo[(*indice)][2];
                (*banco).num_carte++;
                (*indice)++;
            }

        }else{

            (*banco).carte[giri][0]= (*deck).mazzo[(*indice)][0];
            (*banco).carte[giri][1]= (*deck).mazzo[(*indice)][1];
            (*banco).carte[giri][2]= (*deck).mazzo[(*indice)][2];
            (*banco).num_carte++;
            (*indice)++;

        }
        giri++;

    }


}


void Eseguire_Mosse_Giocatore(int num_giocatori,Tgiocatore *giocatore,Tcarte *deck,int *indice,Tbanco *banco,int*salva_esci){


    char scelta;
    int n=0;//conta i giocatori
    int x=70;
    int y=16;
    int esc=0;
    int stand=0;
    int bust;
    Cancellare_Salva();
    do{
        giocatore[n].turni++;
        Stampare_Giocatori(num_giocatori,giocatore,deck,n);
        stand=0;
        Stampare_Info_Giocatore(giocatore,n);
        Abilitare_Hit();
        giocatore[n].hit=1;
        Abilitare_Hit();
        bust=0;
        if(giocatore[n].carte[0][2]==giocatore[n].carte[1][2]&&giocatore[n].puntata<=giocatore[n].credito){
            giocatore[n].split=1;
        }else{
            Oscurare_Split();
        }

        if((*banco).carte[0][0]==0){
            giocatore[n].insurance=1;
        }else{
            Oscurare_Insurance();
        }
        if(giocatore[n].puntata<=giocatore[n].credito){
            giocatore[n].duble=1;
        }else{
            Oscurare_Double();
        }
        Controllo_Blackjack(giocatore,n);
        do{
            if(giocatore[n].punti==21){
                Attivare_Solo_Stand(giocatore,n);
            }
//===============BUST
            if(giocatore[n].punti>21&&bust==0){
                //da rivedere
                gotoxy(37,15);
                colore(12);
                printf("hai fatto BUST");
                colore(CBASE);
                Attivare_Solo_Stand(giocatore,n);
                (*banco).bust++;
                bust=1;
            }

            Stampare_Freccia(x-3,y);
            gotoxy(25,9);
            scelta=Acq_Char();
            Spostamento_Mosse(scelta,x-3,&y);
            gotoxy(25,9);
//==========hit
            if(scelta==INVIO&&y==16&&giocatore[n].hit==1){

                Eseguire_Hit(giocatore,deck,indice,n);
                Sommare_Valore(giocatore,num_giocatori,banco);
                Stampare_Giocatori(num_giocatori,giocatore,deck,n);

                Oscurare_Double();
                giocatore[n].duble=0;

            }
//==========split
            if(scelta==INVIO&&y==20&&giocatore[n].split==1){
                giocatore[n].puntata_split=giocatore[n].puntata;
                Eseguire_Split(giocatore,n);
                Cancellare_Giocatore(num_giocatori,giocatore,deck,n);
                Eseguire_Hit(giocatore,deck,indice,n);
                Eseguire_Hit_Split(giocatore,deck,indice,n);
                Cancellare_Giocatore(num_giocatori,giocatore,deck,n);
                Sommare_Valore(giocatore,num_giocatori,banco);
                Sommare_Valore_Split(giocatore,n,banco);
                Stampare_Giocatori(num_giocatori,giocatore,deck,n);
                Stampare_Giocatori_Split_Oscuro(num_giocatori,giocatore,deck,n);


            }
//==========Duble
            if(scelta==INVIO&&y==22&&giocatore[n].duble==1){

                    Eseguire_Double(giocatore,n);
                    Eseguire_Hit(giocatore,deck,indice,n);
                    Sommare_Valore(giocatore,num_giocatori,banco);
                    Stampare_Giocatori(num_giocatori,giocatore,deck,n);
                    Stampare_Info_Giocatore(giocatore,n);
                    Attivare_Solo_Stand(giocatore,n);

            }
//==========insurance
            if(scelta==INVIO&&y==24&&giocatore[n].insurance==1){
                    Eseguire_Insurance(giocatore,n);

            }

//==========Stand
            if(scelta==INVIO&&y==18){

                gotoxy(37,15);
                printf("               ");
                stand=1;
                Attivare_Solo_Stand(giocatore,n);
            }
//===========TASTO ESC
            if(scelta==ESC){
                (*salva_esci)=1;
            }


        }while(stand==0&&esc==0&&(*salva_esci)==0);
        Cancellare_Giocatore(num_giocatori,giocatore,deck,n);
//=========================================IF CHE GESTISCE SECONDO MAZZO DI SPLIT
//=========================================CON LO SPLIT SAR� DISPLONIBILE SOLO DOUBLE,HIT E STAND
        if(giocatore[n].punti_split>0&&(*salva_esci)==0){
            Stampare_Giocatore_Oscuro(num_giocatori,giocatore,deck,n);
            Stampare_Giocatore_Split(num_giocatori,giocatore,deck,n);

            if(giocatore[n].puntata<=giocatore[n].credito){
                giocatore[n].duble=1;
                Abilitare_Double();
            }else{
                Oscurare_Double();
            }

            giocatore[n].hit=1;
            Abilitare_Hit();
            stand=0;
            do{
                if(giocatore[n].punti_split==21){
                    Attivare_Solo_Stand(giocatore,n);
                }

                Stampare_Freccia(x-3,y);
                gotoxy(25,9);

                scelta=Acq_Char();
                Spostamento_Mosse(scelta,x-3,&y);
                gotoxy(25,9);
//==================HIT PER MAZZO SPLIT
                if(scelta==INVIO&&y==16&&giocatore[n].hit==1){

                    Eseguire_Hit_Split(giocatore,deck,indice,n);
                    Sommare_Valore_Split(giocatore,n,banco);
                    Stampare_Giocatore_Split(num_giocatori,giocatore,deck,n);
                    Oscurare_Double();
                    giocatore[n].duble=0;
                }
//===================DOUBLE PER MAZZO SPLIT
                if(scelta==INVIO&&y==22&&giocatore[n].duble==1){

                    Eseguire_Double(giocatore,n);
                    Eseguire_Hit_Split(giocatore,deck,indice,n);
                    Sommare_Valore_Split(giocatore,n,banco);
                    Stampare_Giocatore_Split(num_giocatori,giocatore,deck,n);
                    Stampare_Info_Giocatore(giocatore,n);
                    Attivare_Solo_Stand(giocatore,n);
                }
//===============BUST
                if(giocatore[n].punti>21){

                    gotoxy(37,15);
                    colore(12);
                    printf("hai fatto BUST");
                    colore(CBASE);
                    Attivare_Solo_Stand(giocatore,n);
                }
//====================STAND PER MAZZO SPLIT
                if(scelta==INVIO&&y==18){

                    gotoxy(37,15);
                    printf("               ");
                    stand=1;
                    Attivare_Solo_Stand(giocatore,n);
                }
//============TASTO ESC
                if(scelta==ESC){
                    (*salva_esci)=1;
                }




            }while(stand==0&&(*salva_esci)==0);

        }
            n++;

    }while(n<num_giocatori&&(*salva_esci)==0);


}

void Eseguire_Hit(Tgiocatore *giocatore,Tcarte *deck,int *indice,int n){

    giocatore[n].carte[giocatore[n].num_carte][0]= (*deck).mazzo[(*indice)][0];
    giocatore[n].carte[giocatore[n].num_carte][1]= (*deck).mazzo[(*indice)][1];
    giocatore[n].carte[giocatore[n].num_carte][2]= (*deck).mazzo[(*indice)][2];
    (*indice)++;
    giocatore[n].num_carte++;

}


void Eseguire_Double(Tgiocatore *giocatore,int n){

    giocatore[n].credito-=giocatore[n].puntata;
    giocatore[n].puntata+=giocatore[n].puntata;


}



void Eseguire_Hit_Split(Tgiocatore *giocatore,Tcarte *deck,int *indice,int turnog){

    giocatore[turnog].carte_split[giocatore[turnog].num_carte_split][0]= (*deck).mazzo[(*indice)][0];
    giocatore[turnog].carte_split[giocatore[turnog].num_carte_split][1]= (*deck).mazzo[(*indice)][1];
    giocatore[turnog].carte_split[giocatore[turnog].num_carte_split][2]= (*deck).mazzo[(*indice)][2];
    (*indice)++;
    giocatore[turnog].num_carte_split++;

}


void Eseguire_Mosse_Banco(Tbanco *banco,Tcarte *deck,int *indice,int num_giocatori){

    Stampare_Banco(banco,deck);
    if((*banco).bust<num_giocatori){
    while((*banco).punti<17){

        Eseguire_Hit_Banco(banco,deck,indice);
        Sommare_Valore_Banco(banco);
    }
    Stampare_Banco(banco,deck);
    }
}

void Eseguire_Hit_Banco(Tbanco *banco,Tcarte *deck,int *indice){

    (*banco).carte[(*banco).num_carte][0]= (*deck).mazzo[(*indice)][0];
    (*banco).carte[(*banco).num_carte][1]= (*deck).mazzo[(*indice)][1];
    (*banco).carte[(*banco).num_carte][2]= (*deck).mazzo[(*indice)][2];
    (*indice)++;
    (*banco).num_carte++;

}


void Distribuire_Vincita(Tgiocatore *giocatore,Tbanco *banco,int num_giocatori,Tcarte *deck){


    int i=0;
    do{
        if(giocatore[i].blackjack_puro==1){
            //colore(giocatore[i].sceltacolore+32);
            Stampare_Giocatori(num_giocatori,giocatore,deck,i);
            gotoxy(37,15);
            printf("                                ");
            gotoxy(37,15);
            colore(12);
            printf("Black jack Puro");
            giocatore[i].credito+=giocatore[i].puntata*2;

        }else{

            if(giocatore[i].blackjack==1){

                if(giocatore[i].punti==(*banco).punti){
                    Stampare_Giocatori(num_giocatori,giocatore,deck,i);
                    gotoxy(37,15);
                    printf("                                ");
                    gotoxy(37,15);
                    colore(12);
                    printf("Hai fatto PUSH");
                    giocatore[i].credito+=giocatore[i].puntata-giocatore[i].puntata_split;

                }else{
                    Stampare_Giocatori(num_giocatori,giocatore,deck,i);
                    gotoxy(37,15);
                    printf("                                ");
                    gotoxy(37,15);
                    colore(12);
                    printf("Black jack");
                    giocatore[i].credito+=(giocatore[i].puntata-giocatore[i].puntata_split)+(giocatore[i].puntata*1.5);

                }

            }else{

                if(giocatore[i].punti<=21){
                    if((*banco).punti<=21){
                        if(giocatore[i].punti==(*banco).punti){
                            Stampare_Giocatori(num_giocatori,giocatore,deck,i);
                            gotoxy(37,15);
                            printf("                                ");
                            gotoxy(37,15);
                            colore(12);
                            printf("Hai fatto PUSH");
                            giocatore[i].credito+=giocatore[i].puntata-giocatore[i].puntata_split;

                        }else{
                            if(giocatore[i].punti>(*banco).punti){
                                Stampare_Giocatori(num_giocatori,giocatore,deck,i);
                                gotoxy(37,15);
                                printf("                                ");
                                gotoxy(37,15);
                                colore(12);
                                printf("Hai VINTO");
                                giocatore[i].credito+=(giocatore[i].puntata-giocatore[i].puntata_split)*2;
                            }else{

                                if((*banco).punti==21&&(*banco).num_carte==2){
                                    Stampare_Giocatori(num_giocatori,giocatore,deck,i);
                                    if(giocatore[i].puntata_ass>0){
                                        giocatore[i].credito+=giocatore[i].puntata_ass*2;
                                        gotoxy(37,15);
                                        printf("                                ");
                                        gotoxy(37,15);
                                        colore(12);
                                        printf("Ricevi l'assicurazione");
                                    }

                                }//if per verificare che banco ha fatto black jack
                            }//altrimenti giocatore minore banco
                        }//altrimenti pareggio banco giocatore

                    }else{

                        Stampare_Giocatori(num_giocatori,giocatore,deck,i);
                        gotoxy(37,15);
                        printf("                                ");
                        gotoxy(37,15);
                        colore(12);
                        printf("Banco bust");

                        giocatore[i].credito+=(giocatore[i].puntata-giocatore[i].puntata_split)*2;
                    }//altrimenti del banco(se ha superato 21)
                }//controllo del giocatore se ha superato 21
            }//else del blackjack

        }//controllo blackjack puro

        if(giocatore[i].punti_split>0&&giocatore[i].punti_split<=21){
            if((*banco).punti<=21){
                if(giocatore[i].punti_split==(*banco).punti){

                    Stampare_Giocatore_Split(num_giocatori,giocatore,deck,i);
                    gotoxy(17,15);
                    printf("                                ");
                    gotoxy(17,15);
                    colore(12);
                    printf("Hai fatto PUSH");
                    giocatore[i].credito+=giocatore[i].puntata_split;

                }else{

                    if(giocatore[i].punti_split>(*banco).punti){
                        Stampare_Giocatore_Split(num_giocatori,giocatore,deck,i);
                        gotoxy(17,15);
                        printf("                                ");
                        gotoxy(17,15);
                        colore(12);
                        printf("Hai VINTO");
                        giocatore[i].credito+=giocatore[i].puntata_split*2;

                    }//if per verificare se il valore � maggiore di quello del banco

                }//else nel caso non c'� stato un pareggio
            }else{
                Stampare_Giocatore_Split(num_giocatori,giocatore,deck,i);
                gotoxy(17,15);
                printf("                                 ");
                gotoxy(17,15);
                colore(12);
                printf("Hai VINTO");
                giocatore[i].credito+=giocatore[i].puntata_split*2;

            }//else se il banco a fatto burst
        }//if per controllo split


        Stampare_Info_Giocatore(giocatore,i);
        Acq_Char();
        Cancellare_Giocatore(num_giocatori,giocatore,deck,i);
        Cancellare_Giocatore_Split(num_giocatori,giocatore,deck,i);

        i++;
    }while(i<num_giocatori);

}
