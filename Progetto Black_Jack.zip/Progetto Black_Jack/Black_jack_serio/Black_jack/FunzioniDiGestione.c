#include "Testa.h"



//funzione che gestisce il posizionamento del cursore di scrittura
void gotoxy(int x,int y){
    COORD CursorPos={x,y};
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(hConsole, CursorPos);
}


//funzione che gestisce il colore dell output
void colore(int n){

//----colore
HANDLE hconsole;
hconsole = GetStdHandle(STD_OUTPUT_HANDLE);
SetConsoleTextAttribute(hconsole,n);

}


//gestisce lo spostamento del "cursore" nel menu principale
void Spostamento_Menuprincipale(char sc,int x,int *y){

//if che controlla se l'utente ha inserito l'input corretto
        if(sc==SU || sc==GIU || sc==INVIO){
//controllo sull input fornito dall utente per verificare se deve "scendere" o "salire" il cursore
            if(sc==SU){ //controllo per evitare di andare oltre le scelte disponibili nel menu(cursore punta nulla)
                if((*y)-1<3){
                    gotoxy(x,(*y));
                    printf(" ");
                    (*y)=9;
                    gotoxy(x,(*y));
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONOERROR

                }else{ //sposta il cursore alla scelta "superiore"
                    gotoxy(x,(*y));
                    printf(" ");
                    if((*y)-1==8){
                        (*y)--;
                    }
                    (*y)--;
                    gotoxy(x,(*y));
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONORIGHT
                }
            }//fine controllo su

            if(sc==GIU){ //controllo per evitare di andare oltre le scelte disponibili nel menu(cursore punta nulla)
                if((*y)+1>9){
                    gotoxy(x,(*y));
                    printf(" ");
                    (*y)=3;
                    gotoxy(x,(*y));
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONOERROR
                }else{ //sposta il cursore alla scelta "superiore"
                    gotoxy(x,(*y));
                    printf(" ");
                    if((*y)+1==8){
                        (*y)++;
                    }
                    (*y)++;
                    gotoxy(x,(*y));
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONORIGHT
                }
            }//fine controllo su



        }

}

//acquisisce un char
char Acq_Char(){

    char scelta;
    scelta=getch();
    return scelta;

}

int Acq_Int(){
    int numero;
    scanf("%d",&numero);
    return numero;
}

//gestisce lo spostamento del "cursore" nel menu delle impostazioni
void Spostamento_Impostazioni(char sc,int x,int *y){

        if(sc==SU || sc==GIU || sc==INVIO){
            if(sc==SU){
                if((*y)-1<3){//controllo per evitare di andare oltre le scelte disponibili nel menu(cursore punta nulla)
                    gotoxy(x,(*y));
                    printf(" ");
                    (*y)=9;
                    gotoxy(x,(*y));
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONOERROR
                }else{//sposta il cursore alla scelta "superiore"
                    gotoxy(x,(*y));
                    printf(" ");
                    if((*y)-1==8){
                        (*y)--;
                    }
                    (*y)--;
                    gotoxy(x,(*y));
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONORIGHT
                }
            }//fine controllo su

            if(sc==GIU){//controllo per evitare di andare oltre le scelte disponibili nel menu(cursore punta nulla)
                if((*y)+1>9){
                    gotoxy(x,(*y));
                    printf(" ");
                    (*y)=3;
                    gotoxy(x,(*y));
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONOERROR
                }else{//sposta il cursore alla scelta "inferiore"
                    gotoxy(x,(*y));
                    printf(" ");
                    if((*y)+1==8){
                        (*y)++;
                    }
                    (*y)++;
                    gotoxy(x,(*y));
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONORIGHT
                }
            }//fine controllo su



        }

}


//controllo spostamento per la scelta del colore delle pedine
void Spostamento_Sceltacolori(char sc,int *x ,int *y ){
        int flag=0;
        if(sc==SU || sc==GIU || sc==INVIO){
            if(sc == SU) {
//varie if di controllo sulla posizione del cursore,nel caso di esito positivo viene incrementata la flag
//per evitare l'autospostamento del cursore
               if((flag==0)&& ((*x)+6==41) && ((*y)+2==4)){//colore fucsia
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=41;
                    (*y)=4;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIAD);
                    //SUONORIGHT
                }
                if((flag==0)&&((*x)==41)&&((*y)+2==6)){//colore giallo
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=41;
                    (*y)=6;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIAD);
                    //SUONORIGHT
                }
                if((flag==0)&&((*x)-6==35)&&((*y)+2==8)){//celeste
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=35;
                    (*y)=8;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIAG);
                }
                if((flag==0)&&((*x)-6==29)&&((*y)-2==6)){//verde
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=29;
                    (*y)=6;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIA);
                    //SUONORIGHT
                }

                if((flag==0)&&((*x)==29)&&((*y)-2==4)){//bianco
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=29;
                    (*y)=4;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIA);
                    //SUONORIGHT
                }

                if((flag==0)&&((*x)+6==35)&&((*y)-2==2)){//rosso
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=35;
                    (*y)=2;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIAS);
                    //SUONORIGHT
                }

            }//fine controllo su

//controllo identico a quello per il tasto SU ma inverso
            if(sc==GIU){

                if((flag==0)&& ((*x)-6==29) && ((*y)+2==4)){//bianco
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=29;
                    (*y)=4;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIA);
                    //SUONORIGHT
                }
                if((flag==0)&&((*x)==29)&&((*y)+2==6)){//verde
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=29;
                    (*y)=6;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIA);
                    //SUONORIGHT
                }
                if((flag==0)&&((*x)+6==35)&&((*y)+2==8)){//celeste
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=35;
                    (*y)=8;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIAG);
                    //SUONORIGHT
                }
                if((flag==0)&&((*x)+6==41)&&((*y)-2==6)){//giallo
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=41;
                    (*y)=6;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIAD);
                    //SUONORIGHT
                }

                if((flag==0)&&((*x)==41)&&((*y)-2==4)){//fucsia
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=41;
                    (*y)=4;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIAD);
                    //SUONORIGHT
                }

                if((flag==0)&&((*x)-6==35)&&((*y)-2==2)){//rosso
                    flag=1;
                    gotoxy((*x),(*y));
                    printf(" ");
                    (*x)=35;
                    (*y)=2;
                    gotoxy((*x),(*y));
                    printf("%c",FRECCIAS);
                    //SUONORIGHT
                }

            }
        }
}


//gestisce lo spostamento del "cursore" nel menu delle impostazioni
void Spostamento_Puntata(char sc,int *x,int y){

        if(sc==DESTRA || sc==SINISTRA || sc==INVIO){
            if(sc==SINISTRA){
                if((*x)-2<26){//controllo per evitare di andare oltre le scelte disponibili nel menu(cursore punta nulla)
                    gotoxy((*x),y);
                    printf(" ");
                    (*x)=49;
                    gotoxy((*x),y);
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONOERROR
                }else{//sposta il cursore alla scelta di destra
                    gotoxy((*x),y);
                    printf(" ");
                    if((*x)==49){
                    (*x)-=3;}
                    (*x)-=4;
                    gotoxy((*x),y);
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONORIGHT
                }
            }//fine controllo su

            if(sc==DESTRA){//controllo per evitare di andare oltre le scelte disponibili nel menu(cursore punta nulla)
                if((*x)+2>49){
                    gotoxy((*x),y);
                    printf(" ");
                    (*x)=26;
                    gotoxy((*x),y);
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONOERROR
                }else{//sposta il cursore alla scelta "inferiore"
                    gotoxy((*x),y);
                    printf(" ");
                    if((*x)==42){
                    (*x)+=3;}
                    (*x)+=4;
                    gotoxy((*x),y);
                    printf("%c",FRECCIA);
                    gotoxy(25,8);
                    //SUONORIGHT

                }
            }//fine controllo su



        }

}


void Resettare_Puntata(int num_giocatori,Tgiocatore *giocatore){

    int i=0;
    while(i<num_giocatori){

        giocatore[i].puntata=0;
        i++;
    }

}

void Sommare_Valore(Tgiocatore *giocatore,int num_giocatori,Tbanco *banco ){
    int i=0;
    int k=0;
    while(i<num_giocatori){

        giocatore[i].punti=0;
        i++;
    }
    i=0;
    while(i<num_giocatori){
        k=0;
        while(k<giocatore[i].num_carte){

            giocatore[i].punti+=giocatore[i].carte[k][2];
            k++;
        }
        if(giocatore[i].punti+10<=21){
            k=0;
            giocatore[i].punti=0;
            while(k<giocatore[i].num_carte){
                if(giocatore[i].carte[k][0]==0&&giocatore[i].punti+10<=21){
                    giocatore[i].punti+=giocatore[i].carte[k][2]+10;
                }else{
                    giocatore[i].punti+=giocatore[i].carte[k][2];
                }
                k++;
            }
        }
        i++;
    }

    (*banco).punti=0;

    i=0;
    while(i<(*banco).num_carte){


        (*banco).punti+=(*banco).carte[i][2];
        i++;

    }

    if((*banco).punti<=21){
        i=0;
        (*banco).punti=0;
        while(i<(*banco).num_carte){
            if((*banco).carte[i][0]==0){
                (*banco).punti+=(*banco).carte[i][2]+10;
            }else{
                (*banco).punti+=(*banco).carte[i][2];
            }
            i++;

        }

    }



}





void Spostamento_Mosse(char sc,int x,int *y){

        if(sc==SU || sc==GIU || sc==INVIO){
            if(sc==SU){
                if((*y)-2<16){//controllo per evitare di andare oltre le scelte disponibili nel menu(cursore punta nulla)

                    /*gotoxy(x,(*y));
                    printf(" ");
                    */
                    Cancellare_Freccia(x,(*y));
                    (*y)=24;
                    /*
                    gotoxy(x,(*y));
                    printf("%c",FRECCIA);
                    */
                    Stampare_Freccia(x,(*y));
                    gotoxy(25,8);
                    //SUONOERROR
                }else{//sposta il cursore alla scelta "superiore"
                    Cancellare_Freccia(x,(*y));
                    (*y)-=2;
                    Stampare_Freccia(x,(*y));
                    gotoxy(25,8);
                    //SUONORIGHT
                }
            }//fine controllo su

            if(sc==GIU){//controllo per evitare di andare oltre le scelte disponibili nel menu(cursore punta nulla)
                if((*y)+1>24){
                    Cancellare_Freccia(x,(*y));
                    (*y)=16;
                    Stampare_Freccia(x,(*y));
                    gotoxy(25,8);
                    //SUONOERROR
                }else{//sposta il cursore alla scelta "inferiore"
                    Cancellare_Freccia(x,(*y));
                    (*y)+=2;
                    Stampare_Freccia(x,(*y));
                    gotoxy(25,8);
                    //SUONORIGHT
                }
            }//fine controllo su



        }

}

void Attivare_Solo_Stand(Tgiocatore *giocatore,int turnog){

    Oscurare_Double();
    Oscurare_Insurance();
    Oscurare_Split();
    Oscurare_Hit();
    giocatore[turnog].duble=0;
    giocatore[turnog].hit=0;
    giocatore[turnog].insurance=0;
    giocatore[turnog].split=0;

}

void Eseguire_Insurance(Tgiocatore *giocatore,int turnog){

    giocatore[turnog].credito-=(giocatore[turnog].puntata/2);
    giocatore[turnog].puntata_ass=(giocatore[turnog].puntata/2);
    Stampare_Info_Giocatore(giocatore,turnog);
    giocatore[turnog].insurance=0;
    Oscurare_Insurance();


}

void Eseguire_Split(Tgiocatore *giocatore,int turnog){

    giocatore[turnog].num_carte_split=1;
    giocatore[turnog].num_carte--;
    //giocatore[turnog].num_carte_split++;
    giocatore[turnog].carte_split[0][0]=giocatore[turnog].carte[1][0];
    giocatore[turnog].carte_split[0][1]=giocatore[turnog].carte[1][1];
    giocatore[turnog].carte_split[0][2]=giocatore[turnog].carte[1][2];
    giocatore[turnog].credito-=giocatore[turnog].puntata;
    giocatore[turnog].puntata+=giocatore[turnog].puntata;
    Stampare_Info_Giocatore(giocatore,turnog);
    giocatore[turnog].split=0;
    Oscurare_Split();

}

void Sommare_Valore_Split(Tgiocatore *giocatore,int turnog,Tbanco *banco ){
    int k=0;
    giocatore[turnog].punti_split=0;
    k=0;

    while(k<giocatore[turnog].num_carte_split){
        giocatore[turnog].punti_split+=giocatore[turnog].carte_split[k][2];
        k++;
    }

    if(giocatore[turnog].punti_split+10<=21){
        k=0;
        giocatore[turnog].punti_split=0;
        while(k<giocatore[turnog].num_carte_split){
                if(giocatore[turnog].carte_split[k][0]==0&&giocatore[turnog].punti_split+10<=21){
                    giocatore[turnog].punti_split+=giocatore[turnog].carte_split[k][2]+10;
                }else{
                    giocatore[turnog].punti_split+=giocatore[turnog].carte_split[k][2];
                }
                k++;
            }
        }
    }



void Sommare_Valore_Banco(Tbanco *banco){
    int i=0;

    (*banco).punti=0;

    i=0;
    while(i<(*banco).num_carte){


        (*banco).punti+=(*banco).carte[i][2];
        i++;

    }

    if((*banco).punti+10<=21){
        i=0;
        (*banco).punti=0;
        while(i<(*banco).num_carte){
            if((*banco).carte[i][0]==0&&(*banco).punti+10<=21){
                (*banco).punti+=(*banco).carte[i][2]+10;
            }else{
                (*banco).punti+=(*banco).carte[i][2];
            }
            i++;

        }

    }
}

void Controllo_Blackjack(Tgiocatore *giocatore,int turnog){

    //int i=0;
    int blackjack_puro[2][2];
    blackjack_puro[0][0]=0;
    blackjack_puro[0][1]=PICCHE;
    blackjack_puro[1][0]=10;
    blackjack_puro[1][1]=PICCHE;

    if(giocatore[turnog].punti==21){
        if(giocatore[turnog].carte[0][0]==blackjack_puro[0][0]||giocatore[turnog].carte[0][0]==blackjack_puro[1][0]){

            if(giocatore[turnog].carte[0][1]==blackjack_puro[0][1]){

                if(giocatore[turnog].carte[1][0]==blackjack_puro[0][0]||giocatore[turnog].carte[1][0]==blackjack_puro[1][0]){

                    if(giocatore[turnog].carte[1][1]==blackjack_puro[0][1]){

                        giocatore[turnog].blackjack_puro=1;

                    }

                }
            }
        }
    }else{

        if(giocatore[turnog].punti==21){

            giocatore[turnog].blackjack=1;

        }

    }


}

void Azzerare_Tutto(Tgiocatore *giocatore,Tbanco *banco,int *indice,int num_giocatori,int*salva_esci){

    int i=0;//dichiarazione e inizializzazione della variabile i
    (*indice)=0;//azeeramento indice "delle carte uscite"
    (*banco).punti=0;//azeramento punti banco
    (*banco).num_carte=0;//azeramento numero carte
    (*banco).bust=0;
    (*salva_esci)=0;
    while(i<num_giocatori){

//azeramento dei vari campi del giocatore
        giocatore[i].puntata=0;
        giocatore[i].punti=0;
//azeramento "delle carte possedute dal giocatore
        giocatore[i].num_carte=0;
        giocatore[i].num_carte_split=0;
//azeramento delle variabili utilizzate in split e assicurazione
        giocatore[i].punti_split=0;
        giocatore[i].puntata_ass=0;

        giocatore[i].turni=0;
//azeramento delle varie "azioni" del giocatore
        giocatore[i].split=0;
        giocatore[i].hit=0;
        giocatore[i].duble=0;
        giocatore[i].insurance=0;
        giocatore[i].blackjack=0;
        giocatore[i].blackjack_puro=0;
        giocatore[i].puntata_split=0;
        i++;
    }//fine while


}// fine Azerare_Tutto()

void Eliminare_Giocatore(Tgiocatore *giocatore,int *num_giocatori){

    int i=0;
    int somma=0;
    int k=0;
    int giocatori_dep[6][2];
    while(i<(*num_giocatori)){

        if(giocatore[i].credito>0){
            somma++;
            giocatori_dep[k][0]=giocatore[i].credito;
            giocatori_dep[k][1]=giocatore[i].sceltacolore;
            k++;
        }
        i++;

    }
    (*num_giocatori)=somma;
    k=0;
    while(k<(*num_giocatori)){

        giocatore[k].credito=giocatori_dep[k][0];
        giocatore[k].sceltacolore= giocatori_dep[k][1];
        k++;
    }


}

void Trovare_Credito_Maggiore(Tgiocatore *giocatore,int num_giocatori,int *max_giocatore){

    int i=0;
    i=0;
    (*max_giocatore)=i;
    while(i<num_giocatori){

        if(giocatore[(*max_giocatore)].credito<giocatore[i].credito){

            (*max_giocatore)=i;
        }
        i++;
    }


}

//funzione per il controllo di una stringa acq da tastiera (input utente)
int Controllo_Nome(tstr nome, int cont){
    int i=0;
    int controllo=0;//controllo pu� acq valore 0(ok),1(errore lunghezza),2(errore char speciale)
    char vet[9];//vettore di 9 elementi che servir� per contenere i char speciali
    vet[0]=124;//|
    vet[1]=92;// "\"
    vet[2]=47;//"/"
    vet[3]=58;//:
    vet[4]=42;//*
    vet[5]=34;//"
    vet[6]=60;//<
    vet[7]=62;//>
    vet[8]=63;//?
    //controllo grandezza nome(se supera 15 char verr� impostato il valore di controllo a 1)
    if(strlen(nome)>15){

        controllo=1;
    }

//ciclo per controllare ogni singolo char della stringa nome per verificare che non siano stati immessi char "speciali"
    while(strlen(nome)>i){

        if((nome[i]=='|')||(nome[i]==92)||(nome[i]=='/')||(nome[i]==':')
           ||(nome[i]=='*')||(nome[i]=='?')||(nome[i]=='"')||(nome[i]=='<')||(nome[i]=='>')){

                controllo=2;
            }
        i++;
    }
//cotrollo su cont, se maggiore di 2 stamper� i mess di errore all "interno" della cornice,se inferiore all esterno
    if(cont>=2){

        if(controllo==1){
            colore(12);
            gotoxy(50,0+cont);
            printf("ERRORE");
            colore(12+CBASE);
            gotoxy(30,1+cont);
            printf("Nome troppo lungo,inserire massimo 15 caratteri");
            colore(CBASE);
            gotoxy(38,2+cont);
            system("pause");
            gotoxy(50,0+cont);
            printf("                    ");
            colore(12+CBASE);
            gotoxy(30,1+cont);
            printf("                                               ");
            colore(CBASE);
            gotoxy(38,2+cont);
            printf("                                           ");

        }//fine if



    }else {
        if(controllo==1){
            colore(12);
            gotoxy(50,6+cont);
            printf("ERRORE");
            colore(12+CBASE);
            gotoxy(30,7+cont);
            printf("Nome troppo lungo,inserire massimo 15 caratteri");
            colore(CBASE);
            gotoxy(38,8+cont);
            system("pause");
            gotoxy(50,6+cont);
            printf("                    ");
            colore(12+CBASE);
            gotoxy(30,7+cont);
            printf("                                               ");
            colore(CBASE);
            gotoxy(38,8+cont);
            printf("                                              ");

        }//fine if
    }//fine else
//cotrollo su cont, se maggiore di 3 stamper� i mess di errore all "interno" della cornice,se inferiore all esterno
    if(cont>=3){
        if(controllo==2){

            colore(12);
            gotoxy(45,0+cont);
            printf("ERRORE");
            colore(12+CBASE);
            gotoxy(20,1+cont);
            printf("I nomi dei file non posso contenere i seguenti caratteri:");
            colore(12);
            gotoxy(44,2+cont);
            printf("%c%c%c%c%c%c%c%c%c",vet[0],vet[1],vet[2],vet[3],vet[4],vet[5],vet[6],vet[7],vet[8]);
            colore(CBASE);
            gotoxy(20,3+cont);
            system("pause");

            gotoxy(45,0+cont);
            printf("                    ");
            colore(12+CBASE);
            gotoxy(20,1+cont);
            printf("                                                           ");
            colore(CBASE);
            gotoxy(44,2+cont);
            printf("                                     ");
            gotoxy(20,3+cont);
            printf("                                     ");


        }//fine if


    }else{
        if(controllo==2){

            colore(12);
            gotoxy(35,6+cont);
            printf("ERRORE");
            colore(12+CBASE);
            gotoxy(10,7+cont);
            printf("I nomi dei file non posso contenere i seguenti caratteri:");
            colore(12);
            gotoxy(34,8+cont);
            printf("%c%c%c%c%c%c%c%c%c",vet[0],vet[1],vet[2],vet[3],vet[4],vet[5],vet[6],vet[7],vet[8]);
            colore(CBASE);
            gotoxy(10,9+cont);
            system("pause");

            gotoxy(35,6+cont);
            printf("                    ");
            colore(12+CBASE);
            gotoxy(10,7+cont);
            printf("                                                           ");
            colore(CBASE);
            gotoxy(34,8+cont);
            printf("                                              ");
            gotoxy(10,9+cont);
            printf("                                              ");


        }//fine if
    }//fine else
    return controllo; //return valore controllo
}

void Copiare_Impostazioni(Tresetta *resetta,Tgiocatore *giocatore,Tsettings opzioni){

    int i=0;
    (*resetta).num_giocatori=opzioni.num_giocatori;
    (*resetta).stile=opzioni.stile;
    (*resetta).difficolta=opzioni.difficolta;
    while(i<opzioni.num_giocatori){

        (*resetta).sceltacolore[i]=giocatore[i].sceltacolore;
        (*resetta).credito[i]=giocatore[i].credito;
        i++;
    }


}

void Caricare_Impostazioni(Tresetta resetta,Tgiocatore *giocatore,int *num_giocatori){

    int i=0;
    (*num_giocatori)=resetta.num_giocatori;

    while(i<(*num_giocatori)){

        giocatore[i].sceltacolore= resetta.sceltacolore[i];
        giocatore[i].credito= resetta.credito[i];
        i++;
    }




}
