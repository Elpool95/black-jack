#include "Testa.h"
int main(){
//impostiamo il nome della barra del titolo
    system("title B L A C K J A C K");
//Impostiamo Colore dello sfondo+scritta del dos
    system("color 20");
    char scelta; //variabile utilizzata per acquisire input dell utente
    int x=1,y=3; //variabile di tipo int utilizzata per il posizionamento della "freccia"
    int flag=0;//flagg usata per uscire dal gioco nel caso assume valore 1
    int salva_esci=0; //varibile che assume valore 0(nessun tasto premuto) 1(esci) 2(salva)
    int indice; //variabile che conta "quante carte sono uscite"
    int controllo=0;// se assume valore 1, vuol dire che l utente ha fatto carica partita, 0 nessuna partita caricata
    int k=0; //inizializzazione(a 0)  variabile k
    int stile;//variabile che contiene lo stile di gioco(classico o americano)
    Tresetta resetta; //struct utilizzata per riportare i valori del giocatore a quelli dell impostazione quando si esce da una partita
    Tgiocatore giocatore[6]; //vettore di struct che indica il giocatore
    Tsettings opzione ; //struct che contiene tutte le informazioni sulle opzioni
    Tcarte deck; //struct che contiene le informazioni del mazzo
    Tbanco banco;//struct che contiene le informazioni del banco
    Trecord record[10];//struct che contiene le informazioni del record
    Opzioni_Predefinite(&opzione,giocatore,&banco);
    Copiare_Impostazioni(&resetta,giocatore,opzione);
    Stampare_Menuprincipale();
 //inizializza il vettore elenco record
    while(k<10){
        strcpy(record[k].nome,"");
        record[k].punteggio=0;
        k++;
    }
   // cartole(&deck);

    do{
        //===========MENU PRINCIPALE===================
        gotoxy(0,9);
        //printf("Selezionare un opzione:");
        gotoxy(x,y);//Funzione utilizzata per stampare in posizione X-Y della console
        printf("%c",FRECCIA);//stampa la define FRECCIA
        gotoxy(25,9);
        scelta=Acq_Char();//acquisisce il char da tastiera (input utente)
        Spostamento_Menuprincipale(scelta,x,&y);// gestisce lo spostamento del "cursore"
        if(scelta==INVIO && y==3){

//=================================NUOVA PARTITA
            system("cls");
            Nuova_Partita(opzione,giocatore,&deck,&banco,record,&salva_esci,&indice);
            Caricare_Impostazioni(resetta,giocatore,&opzione.num_giocatori);
            system("cls");
            Stampare_Menuprincipale();

        }else{
            if(scelta==INVIO && y==4){
//============CARICA PARTITA

                system("cls");
                controllo=Caricare_Partita(giocatore,&opzione,&stile);
                opzione.stile=stile;
                if(controllo==1){  //se la partita � stata caricata con successo avvia le segueti funzioni

                    system("cls");
                    Nuova_Partita(opzione,giocatore,&deck,&banco,record,&salva_esci,&indice);
                }
                system("cls");
                Stampare_Menuprincipale();

            }else{

                if(scelta==INVIO && y==5){
//=================IMPOSTAZIONI
                    //SUONORIGHT
                    system("cls");
                    Impostazioni(&opzione,giocatore,&banco);
                    Copiare_Impostazioni(&resetta,giocatore,opzione);
                    system("cls");
                    Stampare_Menuprincipale();
                }else{

                    if(scelta==INVIO && y==6){
//======================CLASSIFICA
                       Record();
                       system("cls");
                       Stampare_Menuprincipale();

                    }else{

                        if(scelta==INVIO && y==7){

                            Regole();
                            Stampare_Menuprincipale();

                        }else{
//============================USCITA
                            if(scelta==INVIO && y==9){

                                flag++;

                            }

                        }

                    }

                }

            }
        }

    }while(flag==0);

    return 0;
}


void Regole(){

    int fine=0;
    int scelta = 0;
    while(fine==0){
        system("cls");
        printf("REGOLE\n\n1. Scopo del gioco\n2. Premessa\n3. Preparazione del gioco\n4. Svolgimento del gioco\n5. Carte utilizzate e valori\n6. Spegazione dettagliate dei termini\n7. Indietro\n\n");
        printf("scelta: ");
        printf("\n\n\n\n\n\n");
        printf("%c%c%c%c",FRECCIA,FRECCIAD,FRECCIAG,FRECCIAS);
        printf(" =Frecce direzionali per muoversi nei menu'\n");
        printf("Invio =tasto per confermare le scelte\n");
        colore(CNEGATO);
        printf("  ");
        colore(CBASE);
        printf(" = Colore usato per disabilitare una scelta");
        scanf("%d",&scelta);
        fflush(stdin);
        system("cls");

        if(scelta == 7){
            fine = 1;
        }else {
            if (scelta == 1){
                printf("1. Scopo del gioco:\n\n");
                printf("Vincono i giocatori che realizzano un punteggio piu' alto del banco non\nsuperiore a 21. Se superate il 21 fate BUST e perdete la mano.");
                printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
                printf("pagina 1/1\n");
            }
            else if (scelta == 2){
                printf("2. Premessa:\n\n");
                printf("Gli altri giocatori al tavolo sono ininfluenti. La vostra mano e' giocata \nrigorosamente contro quella del banco. Le regole di gioco per il banco sono \ndettate forzatamente, non lasciando alcun potere decisionale al banco.\nSi gioca a carte scoperte.");
                printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
                printf("pagina 1/1\n");
            }
            else if (scelta == 3){
                printf("3. Preparazione del gioco:\n\n");
                printf("- Preparare 2 mazzi da 52 carte francesi\n  (il numero dei mazzi puo' arrivare a 6/8, generalmente si utilizzano 2 mazzi)\n\n");
                printf("- Mischiare i mazzi (per esempio con 2 mazzi formare un mazzo da 104 carte)\n\n");
                printf("- Decidere il numero di giocatori\n  (generalmente si va da 1 fino ad un massimo di 8)\n\n");
                printf("- Ogni giocatore dovra' fare la propria puntata (utilizzando le fiches)\n\n");
                printf("- Il banco distribuira' le carte in senso orario(dalla sinistra del banco),\n  fara' due passate intorno al tavolo in modo tale che i giocatori e il banco\n  abbiano due carte ognuno.\n\n");
                printf("- L'ultima carta del banco puo' essere coperta(all'americana) o\n  scoperta(classico), dipende dallo stile di gioco.");
                printf("\n\n\n\n\n");
                printf("pagina 1/1\n");
            }
            else if (scelta == 4){
                printf("4. Svolgimento del gioco:\n\n");
                printf("Dopo la distribuzione delle carte il gioco si sviluppa in semplici fasi:\n");
                printf(" - Il banco partendo dalla sua sinistra chiedera' ad ogni giocatore cosa vuole\n   fare\n");
                printf(" - Il giocatore potra' chiedere una delle seguenti azioni:\n");
                printf("   - HIT: chiedere una carta aggiuntiva. Il giocatore puo' fare HIT (ricevere\n     una carta) tutte le volte che lo desideri, purche' non faccia bust.\n");
                printf("   - STAND (Rimani): rimani con le due carte iniziali.\n");
                printf("   - DOUBLE DOWN (Raddoppia): Raddoppiare la puntata originale e ottenere solo\n     una carta in piu'. Nella maggior parte dei casi, questa mossa non puo'\n     essere utilizzata dopo HIT.\n");
                printf("   - SPLIT (Dividi): dividere due carte dello stesso valore e giocare\n     separatamente. Crea due mani separate.\n");
                printf("   - SURRENDER (Resa): pagando la meta' della scommessa originale.\n\n");
                printf("\n\n\n\n\n\n");
                printf("pagina 1/2\n");
                system("pause");
                system("cls");
                printf("4. Svolgimento del gioco:\n\n");
                printf("Quando il giocatore effettua le sue mosse deve considerare il valore della sua\nmano e la mano del banco. Deve sempre mirare a ricevere il valore piu' vicino a 21 senza fare BUST.\n");
                printf("- Questa operazione verra' ripetuta per ogni giocatore(in modo tale da definire\n  il punteggio di ogni giocatore)\n");
                printf("- Il banco scopre la sua carta coperta (nel caso del gioco classico si salta\n  questo passaggio)\n");
                printf("- Il banco esegue la \"regola della casa\" che consiste nel fare hit fino al\n  raggiungimento di un valore maggiore o uguale al 17\n");
                printf("- Se il banco fa bust, paga a tutti i giocatori che non hanno superato il 21\n");
                printf("- Se il banco non fa bust, paga a tutti i giocatori che hanno superato il suo\n  punteggio\n");
                printf("- Se il banco pareggia, il giocatore non perde la sua puntata ma non guadagna\n  nulla\n\n");
                printf("\n\n\n\n\n");
                printf("pagina 2/2\n");
            }
            else if (scelta == 5){
                printf("5. Carte utilizzate e valori:\n\n");
                printf("Vengono utilizzate tutte le carte ad esclusione del jolly.\n");
                printf("Le carte numeriche (2, 3, 4, 5, 6, 7, 8, 9, 10) valgono il loro valore nominale.I colori non hanno nessun effetto sul valore (il 4 di fiori avra' lo stesso\nvalore del 4 di quadri).\n");
                printf("Carte con figura (jack, regine, re) hanno tutti valori pari a 10. Come le carte numerate, diversi colori non hanno nessun effetto sul valore delle carte con\nfigura.\n");
                printf("L'ultima carta, l'asso, ha un valore speciale nel blackjack. Esso puo' valere\ncome 1 o 11, a seconda di cosa e' piu' utile in una mano particolare.");
                printf("\n\n\n\n\n\n\n\n\n\n\n\n");
                printf("pagina 1/1\n");
            }
            else if (scelta == 6){
                printf("6. Spegazione dettagliate dei termini:\n\n");
                printf("BUST :\nSe le carte di un giocatore superano 21, allora hanno \"sballato\". Le loro\nscommesse originarie sono immediatamente prese dal banco quando questo avviene.\n\n");
                printf("HIT:\nQuando un giocatore sceglie di prendere un'altra carta dopo che loro 2 iniziali sono state distribuite.\nI giocatori possono chiedere carta quante volte vogliono, purche' non sballino.\n\n");
                printf("STAND:\nQuando un giocatore sceglie di non prendere piu' carte. Questo normalmente\navverra' se un giocatore ha una mano piu' o meno decente o se il mazziere mostra una carta scoperta debole.\n\n");
                printf("DOUBLE DOWN:\nQuesto avviene quando un giocatore raddoppia la sua scommessa dopo che sono\nstate distribuite le prime due carte. Quando un giocatore sceglie di\nraddoppiare normalmente significa che ha una grande possibilita' di fare\nuna mano vincente alla sua terza carta.\n\n");
                printf("pagina 1/4\n");
                system("pause");
                system("cls");

                printf("6. Spegazione dettagliate dei termini:\n\n");
                printf("SPLIT:\nSe nella prima distribuzione il giocatore riceve due carte dello stesso valore\n(ignorate il seme)pue' effettuare lo split cioe':\n- separare le due carte e aggiungere un'uguale puntata sulla seconda;\n- proseguire il gioco come se il giocatore avesse due prime carte;\n- aggiungere una carta su ciascuna carta separata.\nNel caso di due Assi il gioco doppio e' consentito con diritto a una sola HIT.\n\n");
                printf("SURRENDER (Resa):\nLa resa offre a un giocatore la scelta di perdere la propria mano, al costo\ndella meta', della puntata originale. Bisogna prendere tale decisione prima di\nfare qualsiasi altra azione durante la mano. Per esempio, una volta che\nchiedete una terza carta, o dividete, o raddoppiate, la resa non e' piu'\n una opzione disponibile.\n\n");
                printf("BLACK JACK PURO:\nIl Black Jack puro si ottiene quando il giocatore fa 21 con le prime due carte\nassegnategli dal dealer, e si puo' fare solo con un Asso di picche (11)\n e un Jack di picche; questo punteggio batte il banco anche se totalizza 21.\n\n");
                printf("pagina 2/4\n");
                system("pause");
                system("cls");

                printf("6. Spegazione dettagliate dei termini:\n\n");
                printf("BLACK JACK:\nUn blackjack, o naturale, e' un totale di 21 con le vostre prime due carte.\nUn blackjack e' percio' un Asso e una qualsiasi carta che valga dieci, con il\nrequisito addizionale che queste siano le vostre prime due carte.\nSe dividete un paio d'Assi, per esempio, e vi viene una carta che vale 10 su \nuno dei due assi, questo non e' blackjack, ma piuttosto un punteggio di 21.\nLa distinzione e' importante, perche' un blackjack vincente viene pagato 3 a 2\n(puntata moltiplicata per 1,5). Con una scommessa di $10 se ne vincono $15 se\nil giocatore fa un blackjack.");
                printf(" Un blackjack di un giocatore batte qualsiasi\npunteggio del banco ad eccezione di un altro blackjack del banco, incluso un\npunteggio di 21 con tre o piu' carte. Se sia il giocatore che il banco hanno un\nblackjack la mano e' in parita'. In quello americano l' eccezione a questa\nregola e' quando la prima carta del banco e' asso, dieci o figura.\nIn questo caso esiste la possibilita' che il banco effettui il blackjack,\npercio' il giocatore puo' scegliere tra le due opzioni: ricevere subito la\nvincita, ma con la quotazione 1 a 1, oppure aspettare la fine della mano\ncorrente.\n\n");
                printf("\n\n");
                printf("pagina 3/4\n");
                system("pause");
                system("cls");

                printf("6. Spegazione dettagliate dei termini:\n\n");
                printf("PAREGGIO(push):\nSi verifica nel caso in cui il giocatore e il banco ottengono un numero di\npunti pari.\nIn questo caso, normalmente, il giocatore recupera la propria puntata.\n\n");
                printf("ASSICURAZIONE(insurance):\nQuando il banchiere si serve un Asso come carta scoperta, vi e' la possibilita' che faccia Black Jack con la seconda carta, quindi i giocatori possono\nricorrere all'Assicurazione. La posta dell'Assicurazione equivale alla meta'\n della puntata di base (quella sulla casella, per esempio: se il giocatore ha\npuntato 100 l'Assicurazione vale 50). Nel caso il banco realizzi Black Jack\nil giocatore perdera' tutta la puntata iniziale, ma verra' risarcito con il\ndoppio del valore dell'assicurazione (2:1): in pratica e' come se la mano si\nconcludesse con un \"pari\". Nel caso il banco non realizzi un Black Jack\nl'assicurazione viene comunque persa indipendentemente dal risultato\ndella mano.\n\n");
                printf("\n\n\n");
                printf("pagina 4/4\n");
            }
            else{
                printf("Scelta non valida");
                printf("\n\n");
            }
            system("pause");
        }
    }



}
