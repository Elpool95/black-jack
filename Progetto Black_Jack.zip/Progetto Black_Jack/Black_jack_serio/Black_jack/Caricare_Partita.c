#include "Testa.h"


int Caricare_Partita(Tgiocatore *giocatore,Tsettings *opzioni,int *stile){
    FILE *fp;
    int cont=0;
    int flag=0;
    tstr nomefile;
    struct _finddata_t ffblk;
	intptr_t handle = 0;
	int done = 0;
    int controllo=0;
    int i=0;

    gotoxy(0,0);
    printf("CARICA PARTITA");

    gotoxy(0,1);
    printf("================================================================================");
    gotoxy(0,2);

    printf("Elenco Salvataggi:");

    chdir("Salvataggi");

	handle = _findfirst("*.sav",&ffblk);
	if(handle!=-1){
        while(handle && done != -1){
            gotoxy(2,4+cont);
            printf("%s\n",ffblk.name);
            done = _findnext(handle,&ffblk);
            cont++;
        }
	}else{

        printf("Non sono presenti salvataggi\n");

	}

    while(flag==0){
        do{
        gotoxy(0,4+cont);
        printf("Digitare il nome del Salvataggio: ");
        gotoxy(0,5+cont);
        printf("================================================================================");
        gotoxy(0,6+cont);
        printf("Menu' principale = indietro");
        gotoxy(33,4+cont);
        fflush(stdin); gets(nomefile);
        gotoxy(33,4+cont);
        printf("                                       ");
        }while(Controllo_Nome(nomefile,cont)>0);
    if(strcmp(nomefile,"indietro")!=0){

    strcat(nomefile,".sav");
    handle= _findfirst(nomefile,&ffblk);
    if(handle!=-1){
        flag=1;
        controllo=1;
        fp=fopen(nomefile,"rb");
        i=0;
                while(i<6){
                fread(&giocatore[i],sizeof(giocatore[i]),1,fp);
                i++;
            }

        fread(opzioni,sizeof(opzioni),1,fp);
        fread(stile,sizeof(stile),1,fp);


        fclose(fp);
    }else{
            gotoxy(35,cont+1);
            colore(12+CBASE);
            printf("Salvataggio non trovato");
            colore(CBASE);
            gotoxy(30,cont+2);
            system("pause");
            flag=0;
            gotoxy(35,cont+1);
            printf("                          ");
            gotoxy(30,cont+2);
            printf("                                      ");
    }
    }else{
        controllo=0;
        flag=1;
    }
    }
    chdir("..");

    return controllo;
}

