#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <string.h>
#include <conio.h>
#include <time.h>
#include <dir.h>
#define INVIO 13 //Tasto invio
#define SU 72   //valore numero del carattere "freccia su"
#define GIU 80 //valore numero del carattere "freccia giu"
#define DESTRA 77 //valore numero del carattere "freccia destra"
#define SINISTRA 75 //valore numero del carattere "freccia sinistra"
#define FRECCIA 16 //valore numero del carattere "freccia-puntatore sopra"
#define FRECCIAS 31 //valore numero del carattere "freccia-puntatore sinistra"
#define FRECCIAG 30 //valore numero del carattere "freccia-puntatore gi�"
#define FRECCIAD 17 //valore numero del carattere "freccia-puntatore destra"
#define CUORI 3 //valore numero del carattere "cuori"
#define QUADRI 4 //valore numero del carattere "quadri"
#define FIORI 5 //valore numero del carattere "giori"
#define PICCHE 6 ////valore numero del carattere "cuori"
#define CBASE 32
#define MAXGIOCATORI 6
#define RIGHE 23
#define COLONNE 37
#define MAXCARTE 104
#define randomize srand((unsigned)time(NULL))  //macro per inizializzare il valore della random basandoci sull'orologio
#define random(x) rand() % x                   //macro per eseguire la rand che "prelever�" un numero casuale tra 0 e x
#define ANGOLOALTOD 191
#define ANGOLOALTOS 218
#define ANGOLOBASSOD 217
#define ANGOLOBASSOS 192
#define VERTICALE 179
#define ORIZZONTALE 196
#define CCARTA 240
#define RIGHEB 1
#define COLONNEB 37
#define CNEGATO 128
#define COK 112
#define COLONNES 17
#define RIGHES 23
#define ESC 27
#define S 115


    typedef char matrice[25][80];  //matrice che conterr� il nostro campo
    typedef char tstr [10];
    typedef char Tchar[3];

    typedef struct{

        int mazzo[104][3];
        Tchar grafica[13];
        int dep[1][3];
    }Tcarte;


    typedef struct
    {
        int turni;
        int carte[10][3];//attribuiamo le due coordinate alla pedina, X e Y
        int sceltacolore;
        int puntata;
        int credito;
        int punti;
        int num_carte;
        int hit;
        int duble;
        int insurance;
        int puntata_ass;
//variabili per lo split
        int num_carte_split;
        int carte_split[10][3]; //deck che conterr� le carte della seconda mano in caso di split
        int split;
        int punti_split;
        int puntata_split;
//variabili per controllo blackjack e blackjack puro
        int blackjack;
        int blackjack_puro;

    } Tgiocatore;

    typedef struct{

        int punti;
        int carte[10][3];
        int num_carte;
        int bust;
    }Tbanco;

    typedef struct{
        int num_giocatori;
        int rosso; // 1
        int verde;  //  3
        int giallo;  //  5
        int bianco;     // 2
        int celeste;  //  6
        int fucsia;//  4
        int stile; // 0 classico 1 americano
        int difficolta; // difficolta del gioco ( 0 facile, 1 normale , 2 difficile)
    } Tsettings;


    typedef struct{
        char nome[10];
        int punteggio;

    }Trecord;

    typedef struct{
        int num_giocatori;
        int sceltacolore[6];
        int credito[6];
        int stile;
        int difficolta;

    }Tresetta;

//funzioni di stampa
void Stampare_Menuprincipale();
void Stampare_Menuimpostazioni(Tsettings *,Tgiocatore *);
void Menu_Scelta_Colore();
void Stampare_Campo(Tsettings,Tgiocatore *);
void Stampare_Giocatori(int,Tgiocatore *,Tcarte *,int);
void Stampare_Freccia(int,int);
void Cancellare_Freccia(int,int);
void Stampare_Info_Giocatore(Tgiocatore *,int );
void Oscurare_Hit();
void Oscurare_Double();
void Oscurare_Insurance();
void Oscurare_Split();
void Cancellare_Giocatore(int,Tgiocatore *,Tcarte *,int);
void Stampare_Giocatori_Split_Oscuro(int,Tgiocatore *,Tcarte *,int);
void Stampare_Banco(Tbanco *,Tcarte *);
void Menu_Record();
void Stampare_Banco_Americano(Tbanco *,Tcarte *);
void Abilitare_Hit();
void Abilitare_Double();
void Stampare_Giocatore_Oscuro(int,Tgiocatore *,Tcarte *,int);
void Stampare_Giocatore_Split(int,Tgiocatore *,Tcarte *,int);
void Abilitare_Salva();
void Oscurare_Salva();
void Cancellare_Salva();
void Cancellare_Giocatore_Split(int,Tgiocatore *,Tcarte *,int);


//Funzioni di gestione
void gotoxy(int,int);
void colore(int);
void Spostamento_Menuprincipale(char,int,int *);
char Acq_Char();
int Acq_Int();
void Spostamento_Impostazioni(char,int,int *);
void Spostamento_Sceltacolori(char,int *,int *);
void Sommare_Valore(Tgiocatore *,int ,Tbanco *);
void Attivare_Solo_Stand(Tgiocatore *,int);
void Spostamento_Mosse(char,int,int *);
void Sommare_Valore_Banco(Tbanco *);
void Trovare_Credito_Maggiore(Tgiocatore *,int,int *);
void Azzerare_Tutto(Tgiocatore *,Tbanco *,int *,int,int*);
void Eliminare_Giocatore(Tgiocatore *,int *);
void Controllo_Blackjack(Tgiocatore *,int);
void Sommare_Valore_Split(Tgiocatore *,int,Tbanco *);
int Controllo_Nome(tstr,int);
//Impostazioni

void Impostazioni(Tsettings* ,Tgiocatore *,Tbanco *);
void Colore_Giocatori(Tsettings *,Tgiocatore *);
void Scelta_Colore(char,Tsettings *,Tgiocatore *,int);
void Colori_Nonscelti(Tsettings *,int *,Tgiocatore *);
void Opzioni_Predefinite(Tsettings *,Tgiocatore *,Tbanco *);
void Modifica_Difficolta(Tsettings *,Tgiocatore *);

//Nuova Partita

void Nuova_Partita(Tsettings ,Tgiocatore *,Tcarte *,Tbanco *,Trecord *,int *,int *);
void Inizializza_Mazzo(Tcarte *);
void Mischiare_Mazzo(Tcarte *);
void Eseguire_Puntata(int,Tgiocatore *,int *);
void Stampare_Menu_Puntata(int,Tgiocatore *);
void Spostamento_Puntata(char,int *,int);
void Resettare_Puntata(int,Tgiocatore *);
void Distribuire_Carte(Tsettings,Tgiocatore *,Tbanco *,int *,Tcarte *);
void Eseguire_Mosse_Giocatore(int,Tgiocatore *,Tcarte *,int *,Tbanco *,int *);
void Eseguire_Hit(Tgiocatore *,Tcarte *,int *,int);
void Eseguire_Double(Tgiocatore *,int);
void Eseguire_Insurance(Tgiocatore *,int);
void Eseguire_Split(Tgiocatore *,int);
void Eseguire_Hit_Split(Tgiocatore *,Tcarte *,int *,int);
void Eseguire_Mosse_Banco(Tbanco *,Tcarte *,int *,int );
void Eseguire_Hit_Banco(Tbanco *,Tcarte *,int *);
void Distribuire_Vincita(Tgiocatore *,Tbanco *,int,Tcarte *);

//Record

void Record();
void Ordina_Record(Trecord *elenco_record);
void Leggi_Record(Trecord *);
void Scrivi_Record(Tgiocatore *,int ,Trecord *,int);
int Controllo_Record(int *,Trecord *);

//Main

void Copiare_Impostazioni(Tresetta *,Tgiocatore *,Tsettings);
void Caricare_Impostazioni(Tresetta ,Tgiocatore *,int *);

//Caricare Partita & Salvare Partita
int Caricare_Partita(Tgiocatore *,Tsettings *,int *);

void Salvare_Partita(Tgiocatore *,Tsettings *,int *);
