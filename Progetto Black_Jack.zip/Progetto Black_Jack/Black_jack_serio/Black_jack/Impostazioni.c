#include "Testa.h"

void Impostazioni (Tsettings *opzione,Tgiocatore *giocatore,Tbanco *banco){


    char scelta;
    int x=1,y=3;
    int flag=0;
    Stampare_Menuimpostazioni(opzione,giocatore);//stampa interfaccia di impostazioni

    do{
        gotoxy(0,9);
        //printf("Selezionare un opzione:");
        gotoxy(x,y);
        printf("%c",FRECCIA);
        gotoxy(25,9);
        scelta=Acq_Char();//acq char
        Spostamento_Impostazioni(scelta,x,&y);//gestione dello spostamento


        if(scelta==DESTRA && y==3){//aumento giocatori
            (*opzione).num_giocatori++;
            if((*opzione).num_giocatori>6){//se superiore a 6 viene reimpostato il valore 6(valore massimo)
                (*opzione).num_giocatori=6;

            }
            Stampare_Menuimpostazioni(opzione,giocatore);
        }
        if(scelta==SINISTRA && y==3){//diminuisce numero giocatori
            (*opzione).num_giocatori--;
            if((*opzione).num_giocatori<1){//se inferiore a 1 viene reimpostato il valore 1(valore minimo)
                (*opzione).num_giocatori=1;

            }else{
                //elimina dallo schermo il simbolo della picca
                gotoxy(25+((*opzione).num_giocatori*2),3);
                printf(" ");
            }
            Stampare_Menuimpostazioni(opzione,giocatore);
        }
        if(scelta==INVIO && y==4){

            system("cls");
            Colore_Giocatori(opzione, giocatore);//funziona scelta colore
            system("cls");
            Stampare_Menuimpostazioni(opzione,giocatore);
        }
        if(scelta==DESTRA && y==5){

            (*opzione).stile=1;
            Stampare_Menuimpostazioni(opzione,giocatore);
        }
        if(scelta==SINISTRA && y==5){

            (*opzione).stile=0;
            Stampare_Menuimpostazioni(opzione,giocatore);

        }
        if(scelta==DESTRA && y==6){

            (*opzione).difficolta++;
            Modifica_Difficolta(opzione,giocatore);
            if((*opzione).difficolta>2){
                (*opzione).difficolta=2;
            }
            Stampare_Menuimpostazioni(opzione,giocatore);
        }
        if(scelta==SINISTRA && y==6){

            (*opzione).difficolta--;
            Modifica_Difficolta(opzione,giocatore);
            if((*opzione).difficolta<0){
                (*opzione).difficolta=0;
            }
            Stampare_Menuimpostazioni(opzione,giocatore);
        }
        if(scelta==INVIO && y==7){

            Opzioni_Predefinite(opzione,giocatore,banco);
            system("cls");
            Stampare_Menuimpostazioni(opzione,giocatore);
        }
        if(scelta==INVIO && y==9){

            flag++;
        }

    }
    while(flag==0);

}


void Colore_Giocatori(Tsettings *opzione, Tgiocatore *giocatore){
    //azzera i colori selezionati (0 non selezionato/1 selezionato)
    (*opzione).rosso=0;
    (*opzione).bianco=0;
    (*opzione).verde=0;
    (*opzione).giallo=0;
    (*opzione).fucsia=0;
    (*opzione).celeste=0;
    char scelta;//scelta del colore
    int i=0;//indice
    int x=35,y=2;//posizioni x-y
    //stampa i colori
    Menu_Scelta_Colore();
    gotoxy(0,9);
    printf("Seleziona un colore Giocatore %d:",i+1);
    gotoxy(x,y);
    printf("%c",FRECCIAS);

    do{
        gotoxy(32,9);
        scelta=Acq_Char();
        Spostamento_Sceltacolori(scelta,&x,&y);
//======ROSSO=====
       if((scelta==INVIO)&&(x==35)&&(y==2)){
            if((*opzione).rosso==0){

                scelta='1';//imposta a 1(stato selezionato)
                Scelta_Colore(scelta, opzione, giocatore,i);
                colore(CBASE);
                i++;
                //gotoxy(2,12);
                gotoxy(0,9);
                printf("Seleziona un colore Giocatore %d",i+1);

            }
       }
//========fucsia
       if((scelta==INVIO)&&(x==41)&&(y==4)){

            if((*opzione).fucsia==0){
                scelta='4';
                Scelta_Colore(scelta, opzione, giocatore,i);
                colore(CBASE);
                i++;
                gotoxy(0,9);
                printf("Seleziona un colore Giocatore %d",i+1);
            }
       }
       if((scelta==INVIO)&&(x==41)&&(y==6)){

            if((*opzione).giallo==0){
                scelta='5';
                Scelta_Colore(scelta, opzione, giocatore,i);
                colore(CBASE);
                i++;
                gotoxy(0,9);
                printf("Seleziona un colore Giocatore %d",i+1);
            }
       }
       if((scelta==INVIO)&&(x==35)&&(y==8)){

            if((*opzione).celeste==0){
            scelta='6';
            Scelta_Colore(scelta, opzione, giocatore,i);
            colore(CBASE);
            i++;
            gotoxy(0,9);
            printf("Seleziona un colore Giocatore %d",i+1);

        }
       }

       if((scelta==INVIO)&&(x==29)&&(y==6)){

          if((*opzione).verde==0){
            scelta='3';
            Scelta_Colore(scelta, opzione, giocatore,i);
            colore(CBASE);
            i++;
            gotoxy(0,9);
            printf("Seleziona un colore Giocatore %d",i+1);
          }
       }

       if((scelta==INVIO)&&(x==29)&&(y==4)){

            if((*opzione).bianco==0){
                scelta='2';
                Scelta_Colore(scelta, opzione, giocatore,i);
                colore(CBASE);
                i++;
                gotoxy(0,9);
                printf("Seleziona un colore Giocatore %d",i+1);

            }
       }


    }while(i<(*opzione).num_giocatori);

    Colori_Nonscelti(opzione,&i,giocatore);

}


void Scelta_Colore(char scelta, Tsettings *opzione, Tgiocatore *giocatore, int i){

    if(scelta=='1'){
            //rosso
            (*opzione).rosso=1;
            giocatore[i].sceltacolore=12;
            gotoxy(35,3);
            colore(128); //rosso
            printf("%c",CUORI);
    }
    if(scelta=='2'){
                //bianco
                (*opzione).bianco=1;
                giocatore[i].sceltacolore=15;
                gotoxy(30,4);
                colore(128);
                printf("%c",CUORI);
    }

    if(scelta=='3'){
                //verde
                    (*opzione).verde=1;
                    giocatore[i].sceltacolore=10;
                    gotoxy(30,6);
                    colore(128); //rosso
                    printf("%c",CUORI);
            }

                if(scelta=='4'){
                    //fucsia
                        (*opzione).fucsia=1;
                        giocatore[i].sceltacolore=13;
                        gotoxy(40,4);
                        colore(128);
                        printf("%c",CUORI);
                }
                if(scelta=='5'){
                        //giallo
                        (*opzione).giallo=1;
                        giocatore[i].sceltacolore=14;
                        gotoxy(40,6);
                        colore(128); //rosso
                        printf("%c",CUORI);

                }
                if(scelta=='6'){
                            //celeste
                                (*opzione).celeste=1;
                                giocatore[i].sceltacolore=11;
                                gotoxy(35,7);
                                colore(128);
                                printf("%c",CUORI);
                        }


}


void Colori_Nonscelti(Tsettings *opzione,int *i,Tgiocatore *giocatore){


        if((*opzione).rosso==0){
            (*opzione).rosso=1;
            giocatore[*i].sceltacolore=12;
            (*i)++;
        }
    if((*opzione).bianco==0){
        (*opzione).bianco=1;
        giocatore[*i].sceltacolore=15;
        (*i)++;
    }
    if((*opzione).verde==0){

        (*opzione).verde=1;
        giocatore[*i].sceltacolore=10;
        (*i)++;
    }
    if((*opzione).giallo==0){
        (*opzione).giallo=1;
        giocatore[*i].sceltacolore=14;
        (*i)++;
    }
    if((*opzione).fucsia==0){
        (*opzione).fucsia=1;
        giocatore[*i].sceltacolore=13;
        (*i)++;
    }
    if((*opzione).celeste==0){
        (*opzione).celeste=1;
        giocatore[*i].sceltacolore=11;
        (*i)++;
    }


}


void Opzioni_Predefinite(Tsettings *opzione,Tgiocatore *giocatore,Tbanco *banco){
    int i=0;
    (*opzione).num_giocatori=1;
    (*opzione).rosso=1;
    (*opzione).bianco=0;
    (*opzione).verde=0;
    (*opzione).giallo=0;
    (*opzione).fucsia=0;
    (*opzione).celeste=0;
    (*opzione).stile=0;
    (*opzione).difficolta=1;
    giocatore[0].sceltacolore=12;
    giocatore[1].sceltacolore=15;
    giocatore[2].sceltacolore=10;
    giocatore[3].sceltacolore=13;
    giocatore[4].sceltacolore=14;
    giocatore[5].sceltacolore=11;

    while(i<6){
        giocatore[i].turni=0;
        giocatore[i].credito=1000;
        giocatore[i].puntata=0;
        giocatore[i].punti=0;
        giocatore[i].num_carte=0;
        giocatore[i].puntata_ass=0;
        giocatore[i].punti_split=0;
        giocatore[i].puntata_split=0;
        giocatore[i].blackjack=0;
        giocatore[i].blackjack_puro=0;
        i++;
    }
    (*banco).punti=0;
    (*banco).num_carte=0;

}

void Modifica_Difficolta(Tsettings *opzione,Tgiocatore *giocatore){

//assegnamo un valore in base alla difficolta scelto dall utente
    int i=0;
    if((*opzione).difficolta==0){
        while(i<MAXGIOCATORI){
//difficolt� facile
            giocatore[i].credito=1500;
            i++;
        }
    }else{

        if((*opzione).difficolta==1){
//difficolt� media
            while(i<MAXGIOCATORI){
                giocatore[i].credito=1000;
                i++;
            }
        }else{
//difficolt� difficile
            if((*opzione).difficolta==2){
                while(i<MAXGIOCATORI){
                    giocatore[i].credito=500;
                    i++;
                }
            }
        }
    }

}

