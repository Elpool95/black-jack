#include "Testa.h"

void Stampare_Menuprincipale(){
    char simboli[4]={3,4,5,6};
    //char car=16;
    gotoxy(30,0);
    colore(44);
    printf("%c",simboli[0]);
    colore(32);
    printf("%c",simboli[2]);
    colore(44);
    printf("%c",simboli[1]);
    colore(32);
    printf("%c",simboli[3]);
    printf("BLACKJACK");
    colore(44);
    printf("%c",simboli[0]);
    colore(32);
    printf("%c",simboli[2]);
    colore(44);
    printf("%c",simboli[1]);
    colore(32);
    printf("%c",simboli[3]);
    gotoxy(0,1);
    printf("================================================================================\n\n");

    gotoxy(3,3);
    printf("Nuova partita");
    gotoxy(3,4);
    printf("Carica partita");
    gotoxy(3,5);
    printf("Modificare Impostazioni");
    gotoxy(3,6);
    printf("Classifica");
    gotoxy(3,7);
    printf("Aiuto");
    gotoxy(3,9);
    printf("Fine");
    gotoxy(0,10);
    printf("================================================================================");

}


void Stampare_Menuimpostazioni(Tsettings *opzioni,Tgiocatore *giocatore){
    gotoxy(28,0);
    printf("IMPOSTAZIONI");
    gotoxy(0,1);
    printf("===============================================================================");
    gotoxy(3,3);
    printf("Numero giocatori");
    gotoxy(3,4);
    printf("Colore giocatore");
    gotoxy(3,5);
    printf("Stile di gioco");
    gotoxy(3,6);
    printf("Livello di gioco");
    gotoxy(3,7);
    printf("Impostazioni predefinite");
    gotoxy(3,9);
    printf("Indietro");
    gotoxy(0,10);
    printf("===============================================================================");
    gotoxy(23,3);
    printf("%c",FRECCIAD);
    gotoxy(25,3);
    int i=0;
    while((*opzioni).num_giocatori>i){
        colore(giocatore[i].sceltacolore+32);
        printf("%c ",PICCHE);
        i++;
    }
    colore(CBASE);
    gotoxy(37,3);
    printf("%c",FRECCIA);

    gotoxy(23,5);
    printf("%c",FRECCIAD);
    if((*opzioni).stile==0){

        printf("  Classico ");

    }else{

        printf("  Americano");

    }

    gotoxy(37,5);
    printf("%c",FRECCIA);

    gotoxy(23,6);

    printf("%c",FRECCIAD);
    if((*opzioni).difficolta==0){

        printf("  Facile ");

    }else{
        if((*opzioni).difficolta==1){

            printf("  Normale  ");

        }else{

            printf("  Difficile");

        }

    }

    gotoxy(37,6);
    printf("%c",FRECCIA);
}

//stampa l'interfaccia del menu scelta pedina
void Menu_Scelta_Colore(){

    printf("SCELTA COLORE GIOCATORE\n");
    printf("===============================================================================\n\n");
    gotoxy(35,3);
    colore(12); //rosso
    printf("%c",CUORI);

    gotoxy(30,4);
    colore(15);//bianco
    printf("%c",CUORI);

    gotoxy(30,6);
    colore(10); //verde
    printf("%c",CUORI);

    gotoxy(40,4);
    colore(13);//fucsia
    printf("%c",CUORI);
    gotoxy(40,6);
    colore(14);//giallo
    printf("%c",CUORI);
    gotoxy(35,7);
    colore(11);  //celeste
    printf("%c",CUORI);
    colore(CUORI);
    gotoxy(2,10);
    colore(CBASE);

}

void Stampare_Menu_Puntata(int i,Tgiocatore *giocatore){

    gotoxy(27,11);
    if(giocatore[i].credito>=10){

        printf("10");

    }else{

        colore(128);
        printf("10");
        colore(CBASE);
    }

    gotoxy(31,11);
    if(giocatore[i].credito>=50){

        printf("50");
    }else{

        colore(128);
        printf("50");
        colore(CBASE);

    }
    gotoxy(35,11);

    if(giocatore[i].credito>=100){

        printf("100");
    }else{

        colore(128);
        printf("100");
        colore(CBASE);

    }

    gotoxy(39,11);

    if(giocatore[i].credito>=200){

        printf("200");
    }else{

        colore(128);
        printf("200");
        colore(CBASE);

    }

    gotoxy(43,11);

    if(giocatore[i].credito>=500){

        printf("500");
    }else{

        colore(128);
        printf("500");
        colore(CBASE);

    }
    gotoxy(50,11);

    if(giocatore[i].puntata==0){

        colore(128);
        printf("Esegui");
        colore(CBASE);
    }else{

        printf("Esegui");

    }

    colore(giocatore[i].sceltacolore+CBASE);
    gotoxy(1,22);
    printf("Giocatore %d",i+1);
    colore(CBASE);
    gotoxy(1,23);
    printf("Puntata: %d   ",giocatore[i].puntata);
    gotoxy(1,24);
    printf("Credito: %d   ",giocatore[i].credito);

}

/*void Messaggi_Errore(int errore,int x,int y){

    if(errore==0){
        gotoxy(x,y);
        printf("                                                          ");
    }else{
        if(errore==1){
            gotoxy(x,y);
            printf("####ERRORE####\n");
            printf("Credito insufficiente");
            system("pause");
        }


    }


}*/


void Stampare_Campo(Tsettings opzione,Tgiocatore *giocatore){

    gotoxy(1,0);
    printf("Esc=Torna al menu' principale");
    gotoxy(1,1);
    printf("s=Salva");
    gotoxy(70,16);
    colore(COK);
    printf("Hit       ");

    gotoxy(70,17);
    int i=70;
    int k=15;
    while(k<24){

            i=70;
        gotoxy(i,k);
        while(i<80){
            printf("%c",ORIZZONTALE);
            i++;
        }
        k+=2;
    }
    i=69;
    k=15;

    gotoxy(i,k);
    printf("%c",ANGOLOALTOS);

    i=69;
    k=16;
    while(k<25){
        gotoxy(i,k);
        printf("%c",VERTICALE);
        k++;
    }
    k=17;
    while(k<24){
        gotoxy(i,k);
        printf("%c",195);
        k+=2;

    }

    gotoxy(70,18);
    printf("Stand     ");

    gotoxy(70,20);
    printf("Split     ");
    gotoxy(70,24);
    printf("Insurance ");
    gotoxy(70,22);
    printf("Double    ");
    gotoxy(37,0);
    colore(CBASE);
    printf("BANCO");



}

void Abilitare_Salva(){

    colore(CBASE);
    gotoxy(1,1);
    printf("s=Salva");

}

void Oscurare_Salva(){

    colore(CNEGATO);
    gotoxy(1,1);
    printf("s=Salva");

}

void Cancellare_Salva(){

    colore(CBASE);
    gotoxy(1,1);
    printf("          ");

}

void Stampare_Giocatori(int num_giocatori,Tgiocatore *giocatore,Tcarte *deck,int turnog){

        int i=0;
        int colonna=36;
        int riga=22;
        int spostac=-3;


        gotoxy(COLONNE+3,RIGHE-6);
        colore(CBASE);
        printf("%d  ",giocatore[turnog].punti);

        while(i<giocatore[turnog].num_carte){

        spostac+=3;
        colore(CCARTA);
        gotoxy(COLONNE+1+spostac,RIGHE);
        colonna=COLONNE;
        while(colonna<COLONNE+7){
            riga= RIGHE;
            while(riga>RIGHE-5){

                gotoxy(colonna+spostac,riga);
                printf(" ");
                riga--;
            }
            colonna++;
        }



        colonna=COLONNE+spostac;
        while(colonna<COLONNE+7+spostac){


            gotoxy(colonna,RIGHE);
            printf("%c",ORIZZONTALE);
            colonna++;

        }

        colonna=COLONNE+spostac;
        while(colonna<COLONNE+7+spostac){

            colore(CCARTA);
            gotoxy(colonna,RIGHE-5);
            printf("%c",ORIZZONTALE);
            colonna++;

        }

        riga=RIGHE;
        while(riga>RIGHE-5){

            colore(CCARTA);
            gotoxy(COLONNE+spostac,riga);
            printf("%c",VERTICALE);
            riga--;

        }

        riga=RIGHE;
        while(riga>RIGHE-5){

            colore(CCARTA);
            gotoxy(COLONNE+7+spostac,riga);
            printf("%c",VERTICALE);
            riga--;

        }

        gotoxy(COLONNE+spostac,RIGHE);
        printf("%c",ANGOLOBASSOS);
        gotoxy(COLONNE+7+spostac,RIGHE);
        printf("%c",ANGOLOBASSOD);
        gotoxy(COLONNE+spostac,RIGHE-5);
        printf("%c",ANGOLOALTOS);
        gotoxy(COLONNE+7+spostac,RIGHE-5);
        printf("%c",ANGOLOALTOD);
        gotoxy(COLONNE+1+spostac,RIGHE-4);
        printf("%s%c",(*deck).grafica[giocatore[turnog].carte[i][0]],giocatore[turnog].carte[i][1]);
        gotoxy(COLONNE+5+spostac,RIGHE-1);
        if(giocatore[turnog].carte[i][0]==9){
            gotoxy(COLONNE+4+spostac,RIGHE-1);
        }
        printf("%s%c",(*deck).grafica[giocatore[turnog].carte[i][0]],giocatore[turnog].carte[i][1]);
        i++;
    }
    colore(CBASE);
}

void Stampare_Banco(Tbanco *banco,Tcarte *deck){

    int i=0;
    int colonna=36;
    int riga=22;
    int spostac=-3;

        gotoxy(COLONNEB+3,RIGHEB+6);
        printf("%d",(*banco).punti);

        while(i<(*banco).num_carte){

        spostac+=3;
        colore(CCARTA);
        gotoxy(COLONNEB+1+spostac,RIGHEB);
        colonna=COLONNEB;
        while(colonna<COLONNEB+7){
            riga= RIGHEB;
            while(riga<RIGHEB+5){

                gotoxy(colonna+spostac,riga);
                printf(" ");
                riga++;
            }
            colonna++;
        }



        colonna=COLONNEB+spostac;
        while(colonna<COLONNEB+7+spostac){


            gotoxy(colonna,RIGHEB);
            printf("%c",ORIZZONTALE);
            colonna++;

        }

        colonna=COLONNEB+spostac;
        while(colonna<COLONNEB+7+spostac){

            colore(CCARTA);
            gotoxy(colonna,RIGHEB+5);
            printf("%c",ORIZZONTALE);
            colonna++;

        }

        riga=RIGHEB;
        while(riga<RIGHEB+5){

            colore(CCARTA);
            gotoxy(COLONNEB+spostac,riga);
            printf("%c",VERTICALE);
            riga++;

        }

        riga=RIGHEB;
        while(riga<RIGHEB+5){

            colore(CCARTA);
            gotoxy(COLONNEB+7+spostac,riga);
            printf("%c",VERTICALE);
            riga++;

        }

        gotoxy(COLONNEB+spostac,RIGHEB+5);
        printf("%c",ANGOLOBASSOS);
        gotoxy(COLONNEB+7+spostac,RIGHEB+5);
        printf("%c",ANGOLOBASSOD);
        gotoxy(COLONNEB+spostac,RIGHEB);
        printf("%c",ANGOLOALTOS);
        gotoxy(COLONNEB+7+spostac,RIGHEB);
        printf("%c",ANGOLOALTOD);
        gotoxy(COLONNEB+1+spostac,RIGHEB+1);
        printf("%s%c",(*deck).grafica[(*banco).carte[i][0]],(*banco).carte[i][1]);
        gotoxy(COLONNEB+5+spostac,RIGHEB+4);
        if((*banco).carte[i][0]==9){
            gotoxy(COLONNEB+4+spostac,RIGHEB+4);
        }
        printf("%s%c",(*deck).grafica[(*banco).carte[i][0]],(*banco).carte[i][1]);
        i++;
    }
    colore(CBASE);



}

void Stampare_Banco_Americano(Tbanco *banco,Tcarte *deck){

    int i=0;
    int colonna=36;
    int riga=22;
    int spostac=-3;

        gotoxy(COLONNEB+3,RIGHEB+6);
        if((*banco).punti==21){
            if((*banco).carte[0][0]==0){
                printf("%d",(*banco).punti-10);
            }else{
                printf("%d",(*banco).punti-(*banco).carte[1][2]-10);
            }
        }else{

            printf("%d",(*banco).punti-(*banco).carte[1][2]);

        }



        while(i<(*banco).num_carte){

        spostac+=3;
        colore(CCARTA);
        gotoxy(COLONNEB+1+spostac,RIGHEB);
        colonna=COLONNEB;
        while(colonna<COLONNEB+7){
            riga= RIGHEB;
            while(riga<RIGHEB+5){

                gotoxy(colonna+spostac,riga);
                if(i==1){
                    printf("%c",178);
                }else{
                printf(" ");
                }
                riga++;
            }
            colonna++;
        }



        colonna=COLONNEB+spostac;
        while(colonna<COLONNEB+7+spostac){


            gotoxy(colonna,RIGHEB);
            printf("%c",ORIZZONTALE);
            colonna++;

        }

        colonna=COLONNEB+spostac;
        while(colonna<COLONNEB+7+spostac){

            colore(CCARTA);
            gotoxy(colonna,RIGHEB+5);
            printf("%c",ORIZZONTALE);
            colonna++;

        }

        riga=RIGHEB;
        while(riga<RIGHEB+5){

            colore(CCARTA);
            gotoxy(COLONNEB+spostac,riga);
            printf("%c",VERTICALE);
            riga++;

        }

        riga=RIGHEB;
        while(riga<RIGHEB+5){

            colore(CCARTA);
            gotoxy(COLONNEB+7+spostac,riga);
            printf("%c",VERTICALE);
            riga++;

        }

        gotoxy(COLONNEB+spostac,RIGHEB+5);
        printf("%c",ANGOLOBASSOS);
        gotoxy(COLONNEB+7+spostac,RIGHEB+5);
        printf("%c",ANGOLOBASSOD);
        gotoxy(COLONNEB+spostac,RIGHEB);
        printf("%c",ANGOLOALTOS);
        gotoxy(COLONNEB+7+spostac,RIGHEB);
        printf("%c",ANGOLOALTOD);
        gotoxy(COLONNEB+1+spostac,RIGHEB+1);
        if(i!=1){
            printf("%s%c",(*deck).grafica[(*banco).carte[i][0]],(*banco).carte[i][1]);
        }
        gotoxy(COLONNEB+5+spostac,RIGHEB+4);
        if((*banco).carte[i][0]==9){
            gotoxy(COLONNEB+4+spostac,RIGHEB+4);
        }
        if(i!=1){

            printf("%s%c",(*deck).grafica[(*banco).carte[i][0]],(*banco).carte[i][1]);
        }
        i++;
    }
    colore(CBASE);



}


void Stampare_Freccia(int x,int y){
    colore(CBASE);
    gotoxy(x,y);//Funzione utilizzata per stampare in posizione X-Y della console
    printf("%c",FRECCIA);//stampa la define FRECCIA

}

void Cancellare_Freccia(int x,int y){

    gotoxy(x,y);
    printf(" ");

}

void Stampare_Info_Giocatore(Tgiocatore *giocatore,int turnog){


    colore(giocatore[turnog].sceltacolore+CBASE);
    gotoxy(1,22);
    printf("Giocatore %d",turnog+1);
    colore(CBASE);
    gotoxy(1,23);
    printf("Puntata: %d   ",giocatore[turnog].puntata);
    gotoxy(1,24);
    printf("Credito: %d   ",giocatore[turnog].credito);

    if(giocatore[turnog].puntata_ass>0){
        gotoxy(15,24);
        printf("Insurance: %d   ",giocatore[turnog].puntata_ass);
    }

}

void Oscurare_Split(){

    gotoxy(70,20);
    colore(CNEGATO);
    printf("Split");
    colore(CBASE);
}

void Oscurare_Insurance(){

    colore(CNEGATO);
    gotoxy(70,24);
    printf("Insurance");
    gotoxy(25,9);
    colore(CBASE);

}

void Oscurare_Double(){

    colore(CNEGATO);
    gotoxy(70,22);
    printf("Double");
    gotoxy(25,9);
    colore(CBASE);

}

void Oscurare_Hit(){

    colore(CNEGATO);
    gotoxy(70,16);
    printf("Hit");
    gotoxy(25,9);
    colore(CBASE);

}

void Abilitare_Hit(){

    colore(COK);
    gotoxy(70,16);
    printf("Hit");
    gotoxy(25,9);
    colore(CBASE);

}

void Abilitare_Double(){

    colore(COK);
    gotoxy(70,22);
    printf("Double");
    gotoxy(25,9);
    colore(CBASE);

}

void Cancellare_Giocatore(int num_giocatori,Tgiocatore *giocatore,Tcarte *deck,int turnog){

        int i=0;
        int colonna=36;
        int riga=22;
        int spostac=-3;


        while(i<giocatore[turnog].num_carte){

        spostac+=3;
        colore(CBASE);
        gotoxy(COLONNE+1+spostac,RIGHE);
        colonna=COLONNE;
        while(colonna<COLONNE+7){
            riga= RIGHE;
            while(riga>RIGHE-5){

                gotoxy(colonna+spostac,riga);
                printf(" ");
                riga--;
            }
            colonna++;
        }



        colonna=COLONNE+spostac;
        while(colonna<COLONNE+7+spostac){


            gotoxy(colonna,RIGHE);
            printf(" ");
            colonna++;

        }

        colonna=COLONNE+spostac;
        while(colonna<COLONNE+7+spostac){

            colore(CBASE);
            gotoxy(colonna,RIGHE-5);
            printf(" ");
            colonna++;

        }

        riga=RIGHE;
        while(riga>RIGHE-5){

            colore(CBASE);
            gotoxy(COLONNE+spostac,riga);
            printf(" ");
            riga--;

        }

        riga=RIGHE;
        while(riga>RIGHE-5){

            colore(CBASE);
            gotoxy(COLONNE+7+spostac,riga);
            printf(" ");
            riga--;

        }

        gotoxy(COLONNE+spostac,RIGHE);
        printf(" ");
        gotoxy(COLONNE+7+spostac,RIGHE);
        printf(" ");
        gotoxy(COLONNE+spostac,RIGHE-5);
        printf(" ");
        gotoxy(COLONNE+7+spostac,RIGHE-5);
        printf(" ");
        gotoxy(COLONNE+1+spostac,RIGHE-4);
        printf("     ");
        gotoxy(COLONNE+5+spostac,RIGHE-1);
        if(giocatore[turnog].carte[i][0]==9){
            gotoxy(COLONNE+4+spostac,RIGHE-1);
        }
        printf("    ");
        i++;
    }
    colore(CBASE);
}


void Stampare_Giocatori_Split_Oscuro(int num_giocatori,Tgiocatore *giocatore,Tcarte *deck,int turnog){

        int i=0;
        int colonna=16;
        int riga=22;
        int spostac=-3;

        gotoxy(COLONNES+3,RIGHES-6);
        colore(CBASE);
        printf("%d  ",giocatore[turnog].punti_split);

        while(i<giocatore[turnog].num_carte_split){

        spostac+=3;
        colore(CNEGATO);
        gotoxy(COLONNES+1+spostac,RIGHES);
        colonna=COLONNES;
        while(colonna<COLONNES+7){
            riga= RIGHES;
            while(riga>RIGHES-5){

                gotoxy(colonna+spostac,riga);
                printf(" ");
                riga--;
            }
            colonna++;
        }



        colonna=COLONNES+spostac;
        while(colonna<COLONNES+7+spostac){


            gotoxy(colonna,RIGHES);
            printf("%c",ORIZZONTALE);
            colonna++;

        }

        colonna=COLONNES+spostac;
        while(colonna<COLONNES+7+spostac){

            colore(CNEGATO);
            gotoxy(colonna,RIGHES-5);
            printf("%c",ORIZZONTALE);
            colonna++;

        }

        riga=RIGHES;
        while(riga>RIGHES-5){

            colore(CNEGATO);
            gotoxy(COLONNES+spostac,riga);
            printf("%c",VERTICALE);
            riga--;

        }

        riga=RIGHES;
        while(riga>RIGHES-5){

            colore(CNEGATO);
            gotoxy(COLONNES+7+spostac,riga);
            printf("%c",VERTICALE);
            riga--;

        }

        gotoxy(COLONNES+spostac,RIGHES);
        printf("%c",ANGOLOBASSOS);
        gotoxy(COLONNES+7+spostac,RIGHES);
        printf("%c",ANGOLOBASSOD);
        gotoxy(COLONNES+spostac,RIGHES-5);
        printf("%c",ANGOLOALTOS);
        gotoxy(COLONNES+7+spostac,RIGHES-5);
        printf("%c",ANGOLOALTOD);
        gotoxy(COLONNES+1+spostac,RIGHES-4);
        printf("%s%c",(*deck).grafica[giocatore[turnog].carte_split[i][0]],giocatore[turnog].carte_split[i][1]);
        gotoxy(COLONNES+5+spostac,RIGHES-1);
        if(giocatore[turnog].carte_split[i][0]==9){
            gotoxy(COLONNES+4+spostac,RIGHES-1);
        }
        printf("%s%c",(*deck).grafica[giocatore[turnog].carte_split[i][0]],giocatore[turnog].carte_split[i][1]);
        i++;
    }
    colore(CBASE);
}


void Stampare_Giocatore_Oscuro(int num_giocatori,Tgiocatore *giocatore,Tcarte *deck,int turnog){

        int i=0;
        int colonna=36;
        int riga=22;
        int spostac=-3;

        gotoxy(COLONNE+3,RIGHE-6);
        colore(CBASE);
        printf("%d  ",giocatore[turnog].punti);

        while(i<giocatore[turnog].num_carte){

        spostac+=3;
        colore(CNEGATO);
        gotoxy(COLONNE+1+spostac,RIGHE);
        colonna=COLONNE;
        while(colonna<COLONNE+7){
            riga= RIGHE;
            while(riga>RIGHE-5){

                gotoxy(colonna+spostac,riga);
                printf(" ");
                riga--;
            }
            colonna++;
        }
        colonna=COLONNE+spostac;
        while(colonna<COLONNE+7+spostac){
            gotoxy(colonna,RIGHE);
            printf("%c",ORIZZONTALE);
            colonna++;
        }

        colonna=COLONNE+spostac;
        while(colonna<COLONNE+7+spostac){
            colore(CNEGATO);
            gotoxy(colonna,RIGHE-5);
            printf("%c",ORIZZONTALE);
            colonna++;
        }

        riga=RIGHE;
        while(riga>RIGHE-5){

            colore(CNEGATO);
            gotoxy(COLONNE+spostac,riga);
            printf("%c",VERTICALE);
            riga--;

        }

        riga=RIGHE;
        while(riga>RIGHE-5){

            colore(CNEGATO);
            gotoxy(COLONNE+7+spostac,riga);
            printf("%c",VERTICALE);
            riga--;

        }

        gotoxy(COLONNE+spostac,RIGHE);
        printf("%c",ANGOLOBASSOS);
        gotoxy(COLONNE+7+spostac,RIGHE);
        printf("%c",ANGOLOBASSOD);
        gotoxy(COLONNE+spostac,RIGHE-5);
        printf("%c",ANGOLOALTOS);
        gotoxy(COLONNE+7+spostac,RIGHE-5);
        printf("%c",ANGOLOALTOD);
        gotoxy(COLONNE+1+spostac,RIGHE-4);
        printf("%s%c",(*deck).grafica[giocatore[turnog].carte[i][0]],giocatore[turnog].carte[i][1]);
        gotoxy(COLONNE+5+spostac,RIGHE-1);
        if(giocatore[turnog].carte[i][0]==9){
            gotoxy(COLONNE+4+spostac,RIGHE-1);
        }
        printf("%s%c",(*deck).grafica[giocatore[turnog].carte[i][0]],giocatore[turnog].carte[i][1]);
        i++;
    }
    colore(CBASE);
}


void Stampare_Giocatore_Split(int num_giocatori,Tgiocatore *giocatore,Tcarte *deck,int turnog){

        int i=0;
        int colonna=16;
        int riga=22;
        int spostac=-3;

        gotoxy(COLONNES+3,RIGHES-6);
        colore(CBASE);
        printf("%d  ",giocatore[turnog].punti_split);

        while(i<giocatore[turnog].num_carte_split){

        spostac+=3;
        colore(CCARTA);
        gotoxy(COLONNES+1+spostac,RIGHES);
        colonna=COLONNES;
        while(colonna<COLONNES+7){
            riga= RIGHES;
            while(riga>RIGHES-5){

                gotoxy(colonna+spostac,riga);
                printf(" ");
                riga--;
            }
            colonna++;
        }



        colonna=COLONNES+spostac;
        while(colonna<COLONNES+7+spostac){


            gotoxy(colonna,RIGHES);
            printf("%c",ORIZZONTALE);
            colonna++;

        }

        colonna=COLONNES+spostac;
        while(colonna<COLONNES+7+spostac){

            gotoxy(colonna,RIGHES-5);
            printf("%c",ORIZZONTALE);
            colonna++;

        }

        riga=RIGHES;
        while(riga>RIGHES-5){

            gotoxy(COLONNES+spostac,riga);
            printf("%c",VERTICALE);
            riga--;

        }

        riga=RIGHES;
        while(riga>RIGHES-5){

            gotoxy(COLONNES+7+spostac,riga);
            printf("%c",VERTICALE);
            riga--;

        }

        gotoxy(COLONNES+spostac,RIGHES);
        printf("%c",ANGOLOBASSOS);
        gotoxy(COLONNES+7+spostac,RIGHES);
        printf("%c",ANGOLOBASSOD);
        gotoxy(COLONNES+spostac,RIGHES-5);
        printf("%c",ANGOLOALTOS);
        gotoxy(COLONNES+7+spostac,RIGHES-5);
        printf("%c",ANGOLOALTOD);
        gotoxy(COLONNES+1+spostac,RIGHES-4);
        printf("%s%c",(*deck).grafica[giocatore[turnog].carte_split[i][0]],giocatore[turnog].carte_split[i][1]);
        gotoxy(COLONNES+5+spostac,RIGHES-1);
        if(giocatore[turnog].carte_split[i][0]==9){
            gotoxy(COLONNES+4+spostac,RIGHES-1);
        }
        printf("%s%c",(*deck).grafica[giocatore[turnog].carte_split[i][0]],giocatore[turnog].carte_split[i][1]);
        i++;
    }
    colore(CBASE);

}

void Menu_Record(){
    system("cls");
    printf("CLASSIFICA\n");
    printf("===============================================================================\n");
    printf("\n");
    printf(" 1)\n");
    printf(" 2)\n");
    printf(" 3)\n");
    printf(" 4)\n");
    printf(" 5)\n");
    printf(" 6)\n");
    printf(" 7)\n");
    printf(" 8)\n");
    printf(" 9)\n");
    printf("10)\n");
    printf("===============================================================================\n");
    printf("\n");

}


void Cancellare_Giocatore_Split(int num_giocatori,Tgiocatore *giocatore,Tcarte *deck,int turnog){

        int i=0;
        int colonna=16;
        int riga=22;
        int spostac=-3;

        gotoxy(COLONNES+3,RIGHES-6);
        colore(CBASE);
        printf("  ");

        while(i<giocatore[turnog].num_carte_split){

        spostac+=3;
        colore(CBASE);
        gotoxy(COLONNES+1+spostac,RIGHES);
        colonna=COLONNES;
        while(colonna<COLONNES+7){
            riga= RIGHES;
            while(riga>RIGHES-5){

                gotoxy(colonna+spostac,riga);
                printf(" ");
                riga--;
            }
            colonna++;
        }



        colonna=COLONNES+spostac;
        while(colonna<COLONNES+7+spostac){


            gotoxy(colonna,RIGHES);
            printf(" ");
            colonna++;

        }

        colonna=COLONNES+spostac;
        while(colonna<COLONNES+7+spostac){

            gotoxy(colonna,RIGHES-5);
            printf(" ");
            colonna++;

        }

        riga=RIGHES;
        while(riga>RIGHES-5){

            gotoxy(COLONNES+spostac,riga);
            printf(" ");
            riga--;

        }

        riga=RIGHES;
        while(riga>RIGHES-5){

            gotoxy(COLONNES+7+spostac,riga);
            printf(" ");
            riga--;

        }

        gotoxy(COLONNES+spostac,RIGHES);
        printf(" ");
        gotoxy(COLONNES+7+spostac,RIGHES);
        printf(" ");
        gotoxy(COLONNES+spostac,RIGHES-5);
        printf(" ");
        gotoxy(COLONNES+7+spostac,RIGHES-5);
        printf(" ");
        gotoxy(COLONNES+1+spostac,RIGHES-4);
        printf("     ");
        gotoxy(COLONNES+5+spostac,RIGHES-1);
        if(giocatore[turnog].carte_split[i][0]==9){
            gotoxy(COLONNES+4+spostac,RIGHES-1);
        }
        printf("     ");
        i++;
    }
    colore(CBASE);


}
