#include "Testa.h"



void Record(){
    int y=3;//coordinata y(asse y)
    int x=4;//cordinata x(asse x)
    char c; //contenitori di carattere
    FILE *rp; //puntatore al file record
    //chdir("Records");
    rp=fopen("records.txt", "r");// apriamo file in lettyra records.txt
    Menu_Record();//stampare menu record
    c=fgetc(rp);
    while(c!=EOF){
//lettura di un carattere alla volta fino a che non trova un "accapo" o fine file
        while(c!='\n' && c!=EOF){
            gotoxy(x,y);
            printf("%c",c);
            c=fgetc(rp);
            x++;
        }
        x=4;
        y++;
        c=fgetc(rp);
   }
   fclose(rp);
   gotoxy(0,15);
   system("pause");
    //chdir("..");
}


void Scrivi_Record(Tgiocatore *giocatore, int difficolta, Trecord *elenco_record,int max_giocaore){

    FILE *rp;
    tstr nome;
    int controllopunteggio=0;
    int i=0;
    int controllo=0;
    float credito;
    float turni;
    int miopunteggio=0;
/*
    _mkdir("Records");
    chdir("Records");
*/
    credito=giocatore[max_giocaore].credito;
    turni=giocatore[max_giocaore].turni;
    miopunteggio=(credito/turni+((difficolta+1)*1000)); //calcolo punteggio giocatore
    //miopunteggio=100;
    gotoxy(14,5);
    printf("===========================================================");
    gotoxy(14,6);
    printf("||                                                       ||");
    gotoxy(14,7);
    printf("||                                                       ||");
    gotoxy(30,7);
    printf("Il tuo punteggio e': %d",miopunteggio);
    controllopunteggio=Controllo_Record(&miopunteggio, elenco_record);
    gotoxy(14,8);
    printf("||                                                       ||");
    gotoxy(14,9);
    printf("===========================================================");
    if(controllopunteggio>0){

    gotoxy(14,9);
    printf("||                                                       ||");
    gotoxy(14,10);
    printf("||                                                       ||");
    gotoxy(14,11);
    printf("||                                                       ||");
    gotoxy(28,9);
        colore(14+48);
        printf("HAI STABILITO UN NUOVO RECORD !!!");
        colore(CBASE);
        gotoxy(14,12);
        printf("===========================================================");

        while(controllo!=1){
        gotoxy(30,11);
        printf("Inserisci il tuo nikname: ");

            gotoxy(55,11);
            fflush(stdin);
            gets(nome);
            if(strlen(nome)<10){
                controllo=1;
            }else{
                gotoxy(14,10);
                printf("||                                                       ||");
                colore(12);
                gotoxy(30,10);
                printf("ERRORE");
                colore(CBASE);
                printf("Inserire massimo 10 caratteri");
                gotoxy(14,11);
                printf("||                                                       ||");
                gotoxy(30,11);
                system("pause");
                gotoxy(14,10);
                printf("||                                                       ||");
                gotoxy(14,11);
                printf("||                                                       ||");
            }
        }

        strcpy(elenco_record[9].nome, nome);
        elenco_record[9].punteggio=miopunteggio;
     }

//inserisce l'elenco ordinato della classifica nel file
        Ordina_Record(elenco_record);
        rp=fopen("records.txt", "w");
        while (i<10){
            if(elenco_record[i].punteggio!=0){
                fprintf(rp,"%s    %d\n",elenco_record[i].nome,elenco_record[i].punteggio);
                i++;
            }else{
                i=10;
            }
        }
        fclose(rp);
    //chdir("..");
}


int Controllo_Record(int *miopunteggio, Trecord *elenco_record){
//ordina i record e confronta l'ultimo della classifica con il punteggio del giocatore
    int resp=0;
    Ordina_Record(elenco_record);
    if((*miopunteggio)>elenco_record[9].punteggio){
        resp++;
    }
    return resp;
}

void Ordina_Record(Trecord *elenco_record){
//ordina elenco record
    int i=0;
    int j=0;
    tstr nik;
    int supp=0;
    while(i<10){
      j=i+1;
      while(j<10){
         if(elenco_record[j].punteggio>elenco_record[i].punteggio){
            supp=elenco_record[i].punteggio;
            elenco_record[i].punteggio=elenco_record[j].punteggio;
            elenco_record[j].punteggio=supp;
            strcpy(nik,elenco_record[i].nome);
            strcpy(elenco_record[i].nome,elenco_record[j].nome);
            strcpy(elenco_record[j].nome, nik);
         }
         j++;
      }
      i++;
    }
}

//funzione che legge il file records.txt
void Leggi_Record(Trecord *elenco_record){
    int i=0;//indice
    int j=0;//indice
    int k;//indice
    char c;//contenitore char
    FILE *rp;//puntatore a file
    //chdir("Records");//chdir cambia la directory
    rp=fopen("records.txt","r");//apertura file in lettura
    c=fgetc(rp);
    while(c!=EOF && i<10){

            j=0;
            k=0;
            while(k<10){
                elenco_record[i].nome[k]='\0';
                k++;
            }
            while(c!=' ' && c!=EOF){
                elenco_record[i].nome[j]=c;
                c=fgetc(rp);
                j++;
            }
            while(c==' '){
                c=fgetc(rp);
            }
            while(c=='1' || c=='2' || c=='3' || c=='4' || c=='5' || c=='6' || c=='7' || c=='8' || c=='9'|| c=='0'){
                elenco_record[i].punteggio=elenco_record[i].punteggio+(c-48);
                elenco_record[i].punteggio=elenco_record[i].punteggio*10;
                c=fgetc(rp);
                if(c!='1' && c!='2' && c!='3' && c!='4' && c!='5' && c!='6' && c!='7' && c!='8' && c!='9' && c!='0'){
                    elenco_record[i].punteggio=elenco_record[i].punteggio/10;
                }
            }
            while(c=='\n'){
                c=fgetc(rp);
            }
            i++;
        }
        fclose(rp);
        //chdir("..");
}
