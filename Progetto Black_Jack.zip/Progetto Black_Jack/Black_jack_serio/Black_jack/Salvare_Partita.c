#include "Testa.h"

void Salvare_Partita(Tgiocatore *giocatore,Tsettings *opzioni,int *stile){
    int cont=0;
    tstr nomefile;
    int flag=0;
    int i=0;
    FILE *fp;
    _mkdir("Salvataggi");

    struct _finddata_t ffblk;
	intptr_t handle = 0;
	int done = 0;

    gotoxy(0,0);
    printf("SALVA PARTITA");

    gotoxy(0,1);
    printf("================================================================================");
    gotoxy(0,2);
    chdir("Salvataggi");
    printf("Elenco Salvataggi:");

	handle = _findfirst("*.sav",&ffblk);
	if(handle!=-1){
        while(handle && done != -1){
            gotoxy(2,4+cont);
            printf("%s",ffblk.name);
            done = _findnext(handle,&ffblk);
            cont++;
        }
	}else{

        printf("Non sono presenti salvataggi\n");

	}
	//cont=cont-1;
	while(flag==0){
        do{
        gotoxy(0,4+cont);
        printf("Digitare il nome del Salvataggio numero %d: ",cont+1);
        gotoxy(0,5+cont);
        printf("================================================================================");
        gotoxy(0,6+cont);
        printf("Menu' principale = indietro");
        gotoxy(42,4+cont);
        fflush(stdin); gets(nomefile);
        gotoxy(42,4+cont);
        printf("                                       ");
        }while(Controllo_Nome(nomefile,cont)>0);
        if(strcasecmp(nomefile,"indietro")==0){

            flag=1;
        }
        if(strcmp(nomefile,"indietro")!=0){
        strcat(nomefile,".sav");
        chdir("Salvataggi");
        handle= _findfirst(nomefile,&ffblk);
        if(handle==-1){
            flag=1;
            fp=fopen(nomefile,"wb");
            while(i<6){
                fwrite(&giocatore[i],sizeof(giocatore[i]),1,fp);
                i++;
            }

            fwrite(opzioni,sizeof(opzioni),1,fp);
            fwrite(stile,sizeof(stile),1,fp);
            fclose(fp);
        }else{
            gotoxy(30,cont+1);
            printf("vuoi sovrascrivere il salvataggio ? S/N ");
            if(getch()=='s'){
                gotoxy(30,cont+1);
                printf("                                       ");
                    flag=1;
                    fp=fopen(nomefile,"wb");
                    //fwrite(mcampo,sizeof(mcampo),1,fp);
                    i=0;
                    while(i<6){
                        fwrite(&giocatore[i],sizeof(giocatore[i]),1,fp);
                        i++;
                    }
                    //fwrite(banco,sizeof(banco),1,fp);
                    //fwrite(deck,sizeof(deck),1,fp);
                    //fwrite(indice,sizeof(indice),1,fp);
                    fwrite(opzioni,sizeof(opzioni),1,fp);
                    fwrite(stile,sizeof(stile),1,fp);
                    fclose(fp);
                    }
                gotoxy(30,cont+1);
                printf("                                       ");
            }
        }
    }

    chdir("..");
    //printf("Exited the main loop\n");

    //getch();
    }

