#include <windows.h>
void gotoxy(int x,int y)
{
    COORD CursorPos={x,y};
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(hConsole, CursorPos);
}

