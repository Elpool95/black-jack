#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
void colore(int);
void gotoxy(int,int);
void Stampa_Menuprincipale();
void Stampa_Menuimpostazioni();
void Menu_Record();
int main(){
    system("color 20");
    Stampa_Menuprincipale();
    system("pause");
    system("cls");
    Stampa_Menuimpostazioni();
    system("pause");
    system("cls");
    Menu_Record();
    /*int i=;
    colore(i);
    while(i<48){
    printf("valore i=%d\n ciaoooooooooooooooooooooooooooooooooooooooooooooooo\n",i);
    i++;
    colore(i);
    }*/

    return 0;
}

void Stampa_Menuprincipale(){
    char simboli[4]={3,4,5,6};
    gotoxy(30,0);
    printf("%c%c%c%cBLACKJACK%c%c%c%c",simboli[0],simboli[1],simboli[2],simboli[3],simboli[0],simboli[1],simboli[2],simboli[3]);
    gotoxy(0,1);
    printf("================================================================================\n\n");

    gotoxy(3,3);
    printf("Nuova partita");
    gotoxy(3,4);
    printf("Carica partita");
    gotoxy(3,5);
    printf("Impostazioni");
    gotoxy(3,6);
    printf("Top Ten");
    gotoxy(3,7);
    printf("Esci");
    gotoxy(0,9);
    printf("================================================================================");

}


void gotoxy(int x,int y){
    COORD CursorPos={x,y};
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(hConsole, CursorPos);
}

void colore(int n){

//----colore
HANDLE hconsole;
hconsole = GetStdHandle(STD_OUTPUT_HANDLE);
SetConsoleTextAttribute(hconsole,n);

}

void Stampa_Menuimpostazioni(){
    gotoxy(28,0);
    printf("IMPOSTAZIONI");
    gotoxy(0,1);
    printf("===============================================================================");
    gotoxy(3,3);
    printf("Numero giocatori");
    gotoxy(3,4);
    printf("Colore giocatori");
    gotoxy(3,5);
    printf("Abilita/Disabilita Canzone di sottofondo");
    gotoxy(3,6);
    printf("Abilita/Disabilita Effetti audio");
    gotoxy(3,7);
    printf("Impostazioni predefinite");
    gotoxy(3,8);
    printf("Indietro");
    gotoxy(0,10);
    printf("===============================================================================");

}

void Menu_Record(){
    system("cls");
    printf("TOP TEN\n");
    printf("===============================================================================\n");
    printf("\n");
    printf(" 1)\n");
    printf(" 2)\n");
    printf(" 3)\n");
    printf(" 4)\n");
    printf(" 5)\n");
    printf(" 6)\n");
    printf(" 7)\n");
    printf(" 8)\n");
    printf(" 9)\n");
    printf("10)\n");
    printf("===============================================================================\n");
    printf("\n");

}
